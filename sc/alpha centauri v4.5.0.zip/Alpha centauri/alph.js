/* 

  #### Alpha centauri By Yopandelreyz ###
   
   Developer: 
   - Yopandelreyz (wa.me/6281239977516)
   
   Follow Channel Developer:
   - https://whatsapp.com/channel/0029VbBvm6l17EmxNvDZtN2e
   
   Recode:
   - Isi namamu (sosmed)
   
   # Penting
   Jangan hapus credits atau nama developer
   hargai pembuat script ini!

*/