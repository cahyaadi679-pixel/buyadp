// ./source/openai.js
// Alpha AI OpenRouter client (OpenAI-compatible)

const OpenAI = require("openai");
const config = require("../config"); // ambil API key dari config.js

/**
 * Client ke OpenRouter.
 * API key diambil dari config.OPENROUTER_API_KEY
 */
const client = new OpenAI({
  baseURL: "https://openrouter.ai/api/v1",
  apiKey: config.OPENROUTER_API_KEY, // <- langsung dari config.js
});

/**
 * System prompt (persona Alpha AI)
 */
function getAlphaAiSystemPrompt() {
  return {
    role: "system",
    content: [
      "Kamu adalah *Alpha AI*, asisten virtual untuk brand 'Yopan Hosting'.",
      "",
      "Gaya bahasa:",
      "- Santai, sopan, profesional.",
      "",
      "Fungsi utama:",
      "- Menjelaskan jasa hosting, VPS, dan panel Pterodactyl.",
      "- Membantu troubleshooting server.",
      "- Menjawab pertanyaan teknis ringan–menengah.",
      "- Memperbaiki kode (code-fixer).",
      "",
      "Batasan:",
      "- Fokus pada layanan Yopan Hosting.",
      "- Jangan bahas politik, gosip, atau hal tidak relevan.",
      "",
      "Jika user bertanya di luar konteks hosting/server/kode:",
      "- Arahkan pelan-pelan kembali ke layanan Yopan Hosting.",
    ].join("\n"),
  };
}

/**
 * Fungsi utama untuk memanggil model AI
 */
async function alphaChat(messages) {
  if (!config.OPENROUTER_API_KEY) {
    return {
      role: "assistant",
      content:
        "Alpha AI tidak dapat digunakan karena API key belum diset di config.js.",
    };
  }

  try {
    const response = await client.chat.completions.create({
      model: "nvidia/nemotron-nano-12b-v2-vl:free",
      messages,
      extra_body: {
        provider: { sort: "throughput" },
        reasoning: { enabled: true },
      },
    });

    const choice = response?.choices?.[0]?.message;

    if (!choice?.content) {
      return {
        role: "assistant",
        content:
          "Maaf, Alpha AI belum bisa menjawab saat ini. Coba beberapa saat lagi ya 😊",
      };
    }

    return choice;
  } catch (err) {
    console.error("[AlphaAI] Error:", err);
    return {
      role: "assistant",
      content:
        "Alpha AI sedang mengalami gangguan koneksi. Coba lagi nanti ya 🙏",
    };
  }
}

module.exports = {
  alphaChat,
  getAlphaAiSystemPrompt,
};
