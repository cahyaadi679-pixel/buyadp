const fs = require("fs");
const path = require("path");
const axios = require("axios");
const QRCode = require("qrcode");
const TelegramBot = require("node-telegram-bot-api");
const { Client } = require("ssh2");

const config = require("./config");
const pakasir = require("./pakasir");
const ptero = require("./ptero");

const tiktok = require("./source/tiktok");

// Sora2 (Omegatech)
const SORA_API_BASE = "https://omegatech-api.dixonomega.tech/api/ai";
const SORA_API_START = `${SORA_API_BASE}/sora2-create`;
const SORA_API_STATUS = `${SORA_API_BASE}/sora2-status`;
const OMEGATECH_CHANNEL = "https://whatsapp.com/channel/0029VbBvm6l17EmxNvDZtN2e";

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// === Inisialisasi Telegram Bot (global, dipakai seluruh file) ===
const bot = new TelegramBot(config.BOT_TOKEN, { polling: true });


// === Alpha AI (OpenRouter via OpenAI-compatible) ===
let AlphaAI = {};
try { AlphaAI = require("./source/openai"); } catch (e) { AlphaAI = {}; }
const alphaSessions = new Map();
function hasOpenRouterKey() { return !!(config.OPENROUTER_API_KEY); }
async function alphaChatFallback(messages = []) {
  if (!hasOpenRouterKey()) throw new Error("OPENROUTER_API_KEY belum diatur di config.js");
  try {
    const res = await axios.post("https://openrouter.ai/api/v1/chat/completions", {
      model: "openrouter/auto",
      messages
    }, {
      headers: {
        "Authorization": `Bearer ${config.OPENROUTER_API_KEY}`,
        "HTTP-Referer": "https://t.me",
        "X-Title": "AlphaAI Telegram Bot"
      },
      timeout: 60000
    });
    const txt = res.data && res.data.choices && res.data.choices[0] && res.data.choices[0].message && res.data.choices[0].message.content;
    return txt || "Maaf, tidak ada respons dari model.";
  } catch (err) {
    console.error("[AlphaAI Fallback] error:", err?.response?.data || err?.message);
    throw err;
  }
}
async function alphaAIChat(messages = []) {
  if (AlphaAI && typeof AlphaAI.alphaChat === "function") {
    try {
      const out = await AlphaAI.alphaChat(messages);
      if (typeof out === "string") return out;
      if (out && typeof out.content === "string") return out.content;
      if (out && out.message && typeof out.message.content === "string") return out.message.content;
    } catch (e) { console.error("[AlphaAI local] error, fallback...", e?.message); }
  }
  return alphaChatFallback(messages);
}
function isAlphaAIOn(db, chatId){ return !!(db.alpha_ai && db.alpha_ai[String(chatId)]); }
function setAlphaAI(db, chatId, on){ if (!db.alpha_ai) db.alpha_ai = {}; db.alpha_ai[String(chatId)] = !!on; saveDB(db); }
function alphaSystemPrompt(){
  return [
    { role: "system", content: [
      "Kamu adalah *Alpha AI*, asisten Telegram yang ramah dan ringkas.",
      "Bahasa default: Indonesia (kecuali diminta lain).",
      "Jangan membeberkan kunci/API, konfigurasi internal, atau data sensitif.",
      "Jawab jelas, praktis, dan tidak bertele-tele."
    ].join("\n") }
  ];
}


// === Helpers for new features ===
const TMP_DIR = path.join(__dirname, "tmp");
if (!fs.existsSync(TMP_DIR)) { try { fs.mkdirSync(TMP_DIR); } catch {} }

async function downloadTelegramFile(bot, fileId) {
  const f = await bot.getFile(fileId);
  const url = `https://api.telegram.org/file/bot${config.BOT_TOKEN}/${f.file_path}`;
  const res = await axios.get(url, { responseType: "arraybuffer" });
  return Buffer.from(res.data);
}
// === End helpers ===


const DB_PATH = path.join(__dirname, "database.json");
const DATA_DIR = path.join(__dirname, "database");
if (!fs.existsSync(DATA_DIR)) { try { fs.mkdirSync(DATA_DIR); } catch {} }

function escapeHtml(s = "") {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

async function sendSafeError(bot, chatId, title, err, kb = backKeyboard()) {
  const raw =
    err?.response?.data?.message ||
    err?.response?.data?.errors ||
    err?.message ||
    String(err);

  const text = [
    `<b>${escapeHtml(title)}</b>`,
    "",
    "<b>Error:</b>",
    `<pre><code>${escapeHtml(typeof raw === "object" ? JSON.stringify(raw) : raw).slice(0, 3500)}</code></pre>`
  ].join("\n");

  try {
    await bot.sendMessage(chatId, text, { parse_mode: "HTML", reply_markup: kb });
  } catch {}
}

// --- Helper untuk mengatur lebar tombol otomatis (2 kolom utk teks pendek) ---
function packButtons(items, shortLen = 14) {
  const toBtn = (it) => ({ text: it.text, callback_data: it.cb });
  const rows = [];
  let lane = [];
  for (const it of items) {
    const isShort = (it.text || "").length <= shortLen;
    if (isShort) {
      lane.push(it);
      if (lane.length === 2) { rows.push(lane.map(toBtn)); lane = []; }
    } else {
      if (lane.length) { rows.push(lane.map(toBtn)); lane = []; }
      rows.push([toBtn(it)]);
    }
  }
  if (lane.length) rows.push(lane.map(toBtn));
  return rows;
}

function normalizeDB(db){
  if (!db.deposits) db.deposits = [];
  if (!db.users) db.users = [];
  if (!db.transactions) db.transactions = [];
  if (!db.broadcasts) db.broadcasts = [];
  if (!db.settings) db.settings = { script: [] };
  if (!db.reseller_orders) db.reseller_orders = [];
  if (!db.alpha_ai) db.alpha_ai = {};
  return db;
}
function loadDB() {
  try { return normalizeDB(JSON.parse(fs.readFileSync(DB_PATH, "utf-8"))); }
  catch { const init = normalizeDB({}); fs.writeFileSync(DB_PATH, JSON.stringify(init, null, 2)); return init; }
}
function saveDB(db) { fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2)); }
function addUserIfNotExists(db, user) {
  if (!db.users.find(u => u.id === user.id)) {
    db.users.push({ id: user.id, first_name: user.first_name || "", username: user.username || "", joined_at: new Date().toISOString(), last_use: new Date().toISOString() });
    saveDB(db);
  }
}
function touchUser(db, userId) {
  const u = db.users.find(u => u.id === userId);
  if (u) { u.last_use = new Date().toISOString(); saveDB(db); }
}

// helper random string untuk node subdomain
function randomString(len = 4) {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let out = "";
  for (let i = 0; i < len; i++) {
    out += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return out;
}

// ===================== Callback query handler =======================
bot.on("callback_query", async (query) => {
  try {
    const data = query.data || "";
    const from = query.from;

    // Handler SUBDOMAIN_SELECT
    if (data.startsWith("SUBDOMAIN_SELECT:")) {
      const chatId = query.message.chat.id;

      // Cek owner lagi (biar aman kalau ada yang klik button-nya)
      if (from.id !== config.OWNER_ID) {
        await bot.answerCallbackQuery(query.id, {
          text: "❌ Fitur ini khusus owner.",
          show_alert: true
        });
        return;
      }

      const parts = data.split(":");
      // Format: SUBDOMAIN_SELECT:index:hostname:ip
      if (parts.length < 4) {
        await bot.answerCallbackQuery(query.id, {
          text: "Data subdomain tidak valid.",
          show_alert: true
        });
        return;
      }

      const domainIndex = Number(parts[1]);
      const host        = parts[2].trim().toLowerCase();
      const ip          = parts[3].trim();

      const subdomainConfig = config.SUBDOMAIN || config.subdomain || {};
      const doms = Object.keys(subdomainConfig);

      if (Number.isNaN(domainIndex) || domainIndex < 0 || domainIndex >= doms.length) {
        await bot.answerCallbackQuery(query.id, {
          text: "Domain tidak ditemukan!",
          show_alert: true
        });
        return;
      }

      const tld = doms[domainIndex];

      // Fungsi buat record A di Cloudflare
      async function createSubdomain(hostname, targetIp) {
        try {
          const res = await axios.post(
            `https://api.cloudflare.com/client/v4/zones/${subdomainConfig[tld].zone}/dns_records`,
            {
              type: "A",
              name: `${hostname.replace(/[^a-z0-9.-]/gi, "")}.${tld}`,
              content: targetIp.replace(/[^0-9.]/gi, ""),
              ttl: 3600,
              priority: 10,
              proxied: false
            },
            {
              headers: {
                Authorization: `Bearer ${subdomainConfig[tld].apitoken}`,
                "Content-Type": "application/json"
              }
            }
          );

          const body = res.data;
          if (body && body.success) {
            return {
              success: true,
              name: body.result && body.result.name,
              ip: body.result && body.result.content
            };
          } else {
            return {
              success: false,
              error: "Gagal membuat subdomain (respon Cloudflare gagal)."
            };
          }
        } catch (error) {
          const errorMsg =
            (error.response &&
              error.response.data &&
              error.response.data.errors &&
              error.response.data.errors[0] &&
              error.response.data.errors[0].message) ||
            error.message ||
            "Terjadi kesalahan saat request ke Cloudflare!";
          return { success: false, error: errorMsg };
        }
      }

      const domnode = `node${randomString(4)}.${host}`;

      let panelDomain = "";
      let nodeDomain  = "";

      // Buat 2 subdomain: panel & node
      // 1. panel: host.tld
      const resPanel = await createSubdomain(host, ip);
      if (!resPanel.success) {
        await bot.answerCallbackQuery(query.id, {
          text: "Gagal membuat subdomain panel.",
          show_alert: true
        });
        await bot.sendMessage(
          chatId,
          "❌ " + resPanel.error
        );
        return;
      }
      panelDomain = resPanel.name;

      // 2. node: nodeXXXX.host.tld
      const resNode = await createSubdomain(domnode, ip);
      if (!resNode.success) {
        await bot.answerCallbackQuery(query.id, {
          text: "Gagal membuat subdomain node.",
          show_alert: true
        });
        await bot.sendMessage(
          chatId,
          "❌ " + resNode.error
        );
        return;
      }
      nodeDomain = resNode.name;

      await bot.answerCallbackQuery(query.id, {
        text: "✅ Subdomain berhasil dibuat!",
        show_alert: false
      });

      const teks = [
        "*✅ Subdomain Berhasil Dibuat*",
        "",
        `- IP: \`${ip}\``,
        `- Panel: \`${panelDomain}\``,
        `- Node: \`${nodeDomain}\``
      ].join("\n");

      await bot.sendMessage(chatId, teks, {
        parse_mode: "Markdown"
      });

      return;
    }

    // ... kalau di file kamu sudah ada callback_query lain, logic-nya bisa kamu lanjutkan di bawah sini

  } catch (e) {
    console.error("Callback query error:", e);
    if (query.id) {
      bot.answerCallbackQuery(query.id, {
        text: "Terjadi error internal.",
        show_alert: true
      }).catch(() => {});
    }
  }
});

const dbTransaksi = new Map();
const depositPrompt = new Map();
const activeCheckers = new Map();
const resellerPrompt = new Map();

const qcPending = new Map(); // simpan teks /qc per user

// === /installtema state session ===
const installTemaSessions = new Map();

/**
 * Cache daftar tema dari installer GitHub
 * items: [{ index, name, url, type }]
 * type = "manual" | "blueprint"
 */
let installTemaThemeCache = {
  at: 0,
  items: []
};

const INSTALLER_SCRIPT_URL = "bash <(curl -s https://raw.githubusercontent.com/luxzdev02/themeinstaller/main/install.sh)";

const QC_COLOR_MAP = {
  pink: "#f68ac9",
  biru: "#6cace4",
  merah: "#f44336",
  hijau: "#4caf50",
  kuning: "#ffeb3b",
  ungu: "#9c27b0",
  birutua: "#0d47a1",
  birumuda: "#03a9f4",
  abu: "#9e9e9e",
  orange: "#ff9800",
  hitam: "#000000",
  putih: "#ffffff",
  teal: "#008080",
  merahmuda: "#FFC0CB",
  cokelat: "#A52A2A",
  salmon: "#FFA07A",
  magenta: "#FF00FF",
  tan: "#D2B48C",
  wheat: "#F5DEB3",
  deeppink: "#FF1493",
  api: "#B22222",
  birulangit: "#00BFFF",
  jingga: "#FF7F50",
  birulangitcerah: "#1E90FF",
  hotpink: "#FF69B4",
  birumudalangit: "#87CEEB",
  hijaulaut: "#20B2AA",
  merahtua: "#8B0000",
  oranyemerah: "#FF4500",
  cyan: "#48D1CC",
  ungutua: "#BA55D3",
  hijaulumut: "#00FF7F",
  hijaugelap: "#008000",
  birulaut: "#191970",
  oranyetua: "#FF8C00",
  ungukehitaman: "#9400D3",
  fuchsia: "#FF00FF",
  magentagelap: "#8B008B",
  "abu-abutua": "#696969",
  peachpuff: "#FFDAB9",
  hijautua: "#BDB76B",
  merahgelap: "#DC143C",
  goldenrod: "#DAA520",
  emas: "#FFD700",
  perak: "#C0C0C0"
};

// Untuk tombol pilihan warna di /qc
const QC_COLOR_BUTTONS = [
  { id: "pink", label: "pink" },
  { id: "biru", label: "biru" },
  { id: "merah", label: "merah" },
  { id: "hijau", label: "hijau" },
  { id: "kuning", label: "kuning" },
  { id: "ungu", label: "ungu" },
  { id: "birutua", label: "biru tua" },
  { id: "birumuda", label: "biru muda" },
  { id: "abu", label: "abu" },
  { id: "orange", label: "oranye" },
  { id: "hitam", label: "hitam" },
  { id: "putih", label: "putih" },
  { id: "teal", label: "teal" },
  { id: "merahmuda", label: "merah muda" },
  { id: "cokelat", label: "cokelat" },
  { id: "salmon", label: "salmon" },
  { id: "magenta", label: "magenta" },
  { id: "tan", label: "tan" },
  { id: "wheat", label: "wheat" },
  { id: "deeppink", label: "deep pink" },
  { id: "api", label: "api" },
  { id: "birulangit", label: "biru langit" },
  { id: "jingga", label: "jingga" },
  { id: "birulangitcerah", label: "biru langit cerah" },
  { id: "hotpink", label: "hot pink" },
  { id: "birumudalangit", label: "biru muda langit" },
  { id: "hijaulaut", label: "hijau laut" },
  { id: "merahtua", label: "merah tua" },
  { id: "oranyemerah", label: "oranye merah" },
  { id: "cyan", label: "cyan" },
  { id: "ungutua", label: "ungu tua" },
  { id: "hijaulumut", label: "hijau lumut" },
  { id: "hijaugelap", label: "hijau gelap" },
  { id: "birulaut", label: "biru laut" }
];

function formatRupiah(n){ return new Intl.NumberFormat('id-ID').format(Number(n || 0)); }
function rand(min, max){ return Math.floor(Math.random() * (max - min + 1)) + min; }
function capital(s){ return (s||'').charAt(0).toUpperCase() + (s||'').slice(1); }
function tanggal(ts){ return new Date(ts || Date.now()).toLocaleString('id-ID'); }

const RAM_OPTIONS = [
  { key: "1gb", label: "1GB", cpu: 40,  disk: 1000, ram: 1000 },
  { key: "2gb", label: "2GB", cpu: 60,  disk: 1000, ram: 2000 },
  { key: "3gb", label: "3GB", cpu: 80,  disk: 2000, ram: 3000 },
  { key: "4gb", label: "4GB", cpu: 100, disk: 2000, ram: 4000 },
  { key: "5gb", label: "5GB", cpu: 120, disk: 3000, ram: 5000 },
  { key: "6gb", label: "6GB", cpu: 140, disk: 3000, ram: 6000 },
  { key: "7gb", label: "7GB", cpu: 160, disk: 4000, ram: 7000 },
  { key: "8gb", label: "8GB", cpu: 180, disk: 4000, ram: 8000 },
  { key: "9gb", label: "9GB", cpu: 200, disk: 5000, ram: 9000 },
  { key: "10gb",label: "10GB",cpu: 220, disk: 5000, ram:10000 },
  { key: "unlimited", label: "Unlimited", cpu: 0, disk: 0, ram: 0, unlimited: true }
];

function mainMenuKeyboard(isOwner) {
  const menu = [
    { text: "Beli Panel",   cb: "BELIPANEL" },
    { text: "Buy Reseller", cb: "BUYRESELLER" },
    { text: "Listproduk",   cb: "LISTPRODUK" },
    { text: "Owners",   cb: "DEVELOPERS" },
  ];
  if (isOwner) {
    menu.push(
      { text: "Deposit (owner)",      cb: "DEPOSIT_OWNER" },
      { text: "Addproduk (owner)",    cb: "ADDPRODUK_HELP" }, // <-- ditambah
      { text: "Hapus Produk (owner)", cb: "DELPROD_MENU" },
    );
  }
  return { inline_keyboard: packButtons(menu, 14) };
}

function bottomCommandKeyboard() {
  return {
    keyboard: [
      [{ text: "Belipanel" }, { text: "Buyresseler" }],
      [{ text: "Beliadmin Panel" }, { text: "List Produk" }],
    ],
    resize_keyboard: true,
    one_time_keyboard: false,
  };
}

async function sendBottomMenu(bot, chatId) {
  await bot.sendMessage(chatId, "Silakan pilih menu cepat di bawah:", {
    reply_markup: bottomCommandKeyboard(),
  });
}

// === Helper khusus /installtema ===

/**
 * Parse daftar tema dari isi script install.sh
 * Hasil: [{ index, name, url, type }]
 * - enigma DI-SKIP
 * - index 9 & 10 => blueprint (Nebula & Recolor)
 */
function parseThemesFromInstallerScript(scriptText = "") {
  const regex = /(\d+)\)\s+THEME_NAME="([^"]+)";\s+THEME_URL="([^"]+)";/g;
  const items = [];
  let m;
  while ((m = regex.exec(scriptText)) !== null) {
    const index = parseInt(m[1], 10);
    const name = m[2];
    const url = m[3];

    // Skip Enigma sesuai requirement
    if (name.toLowerCase() === "enigma") continue;

    const type = (index === 9 || index === 10) ? "blueprint" : "manual";

    items.push({ index, name, url, type });
  }
  items.sort((a, b) => a.index - b.index);
  return items;
}

/**
 * Ambil daftar tema dari GitHub (cache 5 menit)
 */
async function fetchInstallTemaThemeList() {
  const now = Date.now();
  if (installTemaThemeCache.items.length && now - installTemaThemeCache.at < 5 * 60 * 1000) {
    return installTemaThemeCache.items;
  }
  const res = await axios.get(INSTALLER_SCRIPT_URL, { timeout: 20000 });
  const script = String(res.data || "");
  const items = parseThemesFromInstallerScript(script);
  installTemaThemeCache = { at: now, items };
  return items;
}

/**
 * Kirim daftar tema sebagai inline keyboard
 */
async function sendInstallTemaKeyboard(bot, chatId) {
  try {
    const themes = await fetchInstallTemaThemeList();
    if (!themes.length) {
      await bot.sendMessage(chatId, "❌ Gagal mengambil daftar tema dari installer.\nCoba lagi beberapa saat.");
      return;
    }

    const buttons = themes.map(t => ({
      text: `${t.name} ${t.type === "blueprint" ? "🔷" : "🎨"}`,
      cb: `INSTALLTEMA:${t.index}`
    }));

    await bot.sendMessage(chatId, "Pilih tema yang ingin diinstall:", {
      reply_markup: { inline_keyboard: packButtons(buttons, 18) }
    });
  } catch (e) {
    console.error("[/installtema] fetchInstallTemaThemeList error:", e?.message);
    await bot.sendMessage(chatId, "❌ Gagal mengambil daftar tema dari GitHub.\nPastikan VPS / jaringan kamu lancar lalu coba lagi.");
  }
}

/**
 * Jalankan satu script bash di VPS via SSH
 * vps = { host, port, username, password }
 * script = string (akan dijalankan dengan: bash -lc "<script>")
 */
function runSSHScript(vps, script) {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    conn
      .on("ready", () => {
        const cmd = "bash -lc " + JSON.stringify(script);
        conn.exec(cmd, { pty: true }, (err, stream) => {
          if (err) {
            conn.end();
            return reject(err);
          }
          let stderr = "";
          stream.on("close", (code) => {
            conn.end();
            if (code === 0) return resolve();
            return reject(new Error(stderr || `Perintah SSH gagal dengan kode ${code}`));
          });
          stream.stderr.on("data", (data) => {
            stderr += data.toString();
          });
        });
      })
      .on("error", (err) => {
        return reject(err);
      })
      .connect({
        host: vps.host,
        port: vps.port,
        username: vps.username,
        password: vps.password,
        readyTimeout: 25000
      });
  });
}

// Format log SSH biar nggak terlalu panjang
function formatSSHLog(log, maxLen = 3500) {
  log = (log || "").toString().trim();
  if (!log) return "Tidak ada output dari VPS.";
  if (log.length <= maxLen) return log;
  return "...(log dipotong, hanya bagian akhir yang ditampilkan)...\n" + log.slice(-maxLen);
}

/**
 * Flow penuh instal tema via SSH (manual / blueprint / Nebula / Recolor)
 */
async function installThemeViaSSH(bot, chatId, from, vpsData, theme) {
  const { host, port, username, password } = vpsData;
  const themeName = String(theme.name || "").trim();
  const themeUrl = theme.url;
  const nameLower = themeName.toLowerCase();
  const isNebula = nameLower.includes("nebula");
  const isRecolor = nameLower.includes("recolor");
  const isBlueprint = theme.type === "blueprint";

  try {
    const vps = { host, port, username, password };

    await bot.sendMessage(chatId, "🔌 Menghubungkan ke VPS...");
    // Test login sederhana
    await runSSHScript(vps, "echo 'OK LOGIN'");

    await bot.sendMessage(chatId, "✅ Login berhasil.\n");

    let result;
    let title;

    // Nebula & Recolor: wajib lewat dependensi blueprint dulu (setara menu 8)
    if (isBlueprint && (isNebula || isRecolor)) {
      await bot.sendMessage(
        chatId,
        "📦 Menginstall dependensi Blueprint (install_depend)..."
      );
      const depsScript = buildBlueprintDepsScript();
      const depsResult = await runSSHScript(vps, depsScript);

      await bot.sendMessage(
        chatId,
        `✅ Dependensi Blueprint selesai.\n✨ Sedang menginstall tema ${themeName} (Blueprint)...`
      );

      const themeScript = buildBlueprintThemeScript(themeName, themeUrl);
      const themeResult = await runSSHScript(vps, themeScript);

      const combinedLog = formatSSHLog(
        (depsResult.stdout || "") + "\n" + (themeResult.stdout || "")
      );
      title = `🎉 Tema ${themeName} berhasil diinstall tanpa kendala!`;
      await bot.sendMessage(
        chatId,
        `${title}\n\n<b>Log VPS:</b>\n<pre><code>${escapeHtml(
          combinedLog
        )}</code></pre>`,
        { parse_mode: "HTML" }
      );
      return;
    }

    // Blueprint lain (kalau nanti ada)
    if (isBlueprint) {
      await bot.sendMessage(
        chatId,
        `✨ Sedang menginstall tema ${themeName} (Blueprint)...`
      );
      const res = await runSSHScript(
        vps,
        buildBlueprintThemeScript(themeName, themeUrl)
      );
      const log = formatSSHLog(res.stdout || res.stderr || "");
      title = `🎉 Tema ${themeName} berhasil diinstall!`;
      await bot.sendMessage(
        chatId,
        `${title}\n\n<b>Log VPS:</b>\n<pre><code>${escapeHtml(
          log
        )}</code></pre>`,
        { parse_mode: "HTML" }
      );
      return;
    }

    // Tema manual: Stellar, Billing, Elysium, Nightcore, Ice, dll
    await bot.sendMessage(
      chatId,
      `✨ Sedang menginstall tema ${themeName} (manual)...\nProses ini bisa memakan waktu beberapa menit, tergantung VPS.`
    );
    const manualRes = await runSSHScript(
      vps,
      buildManualThemeScript(themeName, themeUrl)
    );
    const manualLog = formatSSHLog(
      manualRes.stdout || manualRes.stderr || ""
    );
    title = `🎉 Tema ${themeName} berhasil diinstall!`;

    await bot.sendMessage(
      chatId,
      `${title}\n\n<b>Log VPS:</b>\n<pre><code>${escapeHtml(
        manualLog
      )}</code></pre>`,
      { parse_mode: "HTML" }
    );
  } catch (err) {
    console.error("[/installtema] SSH error:", err?.message);
    const rawLog =
      (err && (err.stderr || err.stdout)) ||
      err?.message ||
      String(err || "Unknown error");
    const msg = formatSSHLog(rawLog);

    await bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat instalasi tema.\nPesan VPS:\n<pre><code>" +
        escapeHtml(msg) +
        "</code></pre>",
      { parse_mode: "HTML" }
    );
  }
}

/**
 * Script install tema manual (Stellar, Billing, Elysium, dst)
 */
function buildManualThemeScript(themeName, themeUrl) {
  const isBilling = themeName.toLowerCase() === "billing";

  return `
set -e
export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a

TEMP_DIR=$(mktemp -d)
cd "$TEMP_DIR"

echo "Memulai instalasi tema ${themeName}..."
echo "[1/4] Mengunduh file tema..."
wget -q "${themeUrl}"

THEME_ZIP_FILE=$(basename "${themeUrl}")

echo "[2/4] Mengekstrak file tema..."
unzip -oq "$THEME_ZIP_FILE" || true

echo "[3/4] Menyalin file & membangun aset..."
sudo cp -rfT pterodactyl /var/www/pterodactyl

echo "Memastikan Node.js v16 aktif menggunakan NVM..."
export NVM_DIR="$HOME/.nvm"
if [ -s "$NVM_DIR/nvm.sh" ]; then
  . "$NVM_DIR/nvm.sh"
else
  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash > /dev/null 2>&1
  . "$NVM_DIR/nvm.sh"
fi

nvm install 16 > /dev/null 2>&1
nvm use 16 > /dev/null 2>&1
npm i -g yarn > /dev/null 2>&1

cd /var/www/pterodactyl

echo "Menginstal dependensi Node.js..."
yarn > /dev/null 2>&1
yarn add react-feather > /dev/null 2>&1

${isBilling ? 'echo "Menjalankan instalasi spesifik untuk Billing..."; php artisan billing:install stable > /dev/null 2>&1' : ''}

echo "Menjalankan migrasi, build, dan optimisasi..."
php artisan migrate --force > /dev/null 2>&1
yarn build:production > /dev/null 2>&1
php artisan view:clear > /dev/null 2>&1
php artisan optimize:clear > /dev/null 2>&1

echo "[4/4] Membersihkan file sisa..."
rm -rf "$TEMP_DIR"

echo "INSTALASI TEMA ${themeName} SELESAI"
`;
}

/**
 * Script install dependensi Blueprint (setara menu #8: install_depend)
 * (diambil & disederhanakan dari bagian uninstall_panel di installer)
 */
function buildBlueprintDepsScript() {
  return `
set -e
export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a

echo "Menginstal paket dasar (curl, git, unzip, dll)..."
sudo apt-get install -y ca-certificates curl gnupg zip unzip git wget > /dev/null 2>&1

echo "Menyiapkan repositori Node.js v20.x..."
sudo mkdir -p /etc/apt/keyrings
curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | sudo gpg --dearmor | sudo tee /etc/apt/keyrings/nodesource.gpg > /dev/null
echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_20.x nodistro main" | sudo tee /etc/apt/sources.list.d/nodesource.list > /dev/null

echo "Menginstal Node.js & Yarn..."
sudo apt-get update > /dev/null 2>&1
sudo apt-get install -y nodejs > /dev/null 2>&1
sudo npm i -g yarn > /dev/null 2>&1

echo "Menginstal dependensi Pterodactyl di /var/www/pterodactyl..."
cd /var/www/pterodactyl
yarn > /dev/null 2>&1
yarn add cross-env > /dev/null 2>&1

echo "Mengunduh & memasang Blueprint Framework..."
wget -q "$(curl -s https://api.github.com/repos/BlueprintFramework/framework/releases/latest | grep 'browser_download_url' | cut -d '"' -f 4)" -O /tmp/release.zip
unzip -oq /tmp/release.zip -d /var/www/pterodactyl
rm /tmp/release.zip

cd /var/www/pterodactyl
sed -i -E -e "s|WEBUSER=\\"www-data\\" #;|WEBUSER=\\"www-data\\" #;|g" \\
  -e "s|USERSHELL=\\"/bin/bash\\" #;|USERSHELL=\\"/bin/bash\\" #;|g" \\
  -e "s|OWNERSHIP=\\"www-data:www-data\\" #;|OWNERSHIP=\\"www-data:www-data\\" #;|g" blueprint.sh

chmod +x blueprint.sh

echo "Menjalankan blueprint.sh..."
yes | sudo bash blueprint.sh

echo "INSTALLASI NODE.JS & BLUEPRINT SELESAI"
`;
}

/**
 * Script install tema blueprint (Nebula / Recolor)
 */
function buildBlueprintThemeScript(themeName, themeUrl) {
  const nameLower = themeName.toLowerCase();
  return `
set -e
export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a

TEMP_DIR=$(mktemp -d)
cd "$TEMP_DIR"

echo "Mengunduh file tema ${themeName} (Blueprint)..."
wget -q "${themeUrl}"

THEME_ZIP_FILE=$(basename "${themeUrl}")
unzip -oq "$THEME_ZIP_FILE"

THEME_NAME_LOWER="${nameLower}"
BLUEPRINT_FILE="\${THEME_NAME_LOWER}.blueprint"

if [ ! -f "$BLUEPRINT_FILE" ]; then
  echo "File blueprint $BLUEPRINT_FILE tidak ditemukan di dalam zip."
  exit 1
fi

echo "Memindahkan blueprint ke /var/www/pterodactyl..."
sudo mv "$BLUEPRINT_FILE" /var/www/pterodactyl/

cd /var/www/pterodactyl

echo "Menjalankan blueprint -install ${nameLower}..."
sudo blueprint -install "$THEME_NAME_LOWER"

sudo chown -R www-data:www-data /var/www/pterodactyl

echo "Membersihkan file blueprint..."
sudo rm "/var/www/pterodactyl/$BLUEPRINT_FILE"

rm -rf "$TEMP_DIR"

echo "INSTALASI BLUEPRINT ${themeName} SELESAI"
`;
}

/**
 * Flow penuh instal tema via SSH (manual / blueprint / Nebula)
 */
async function installThemeViaSSH(bot, chatId, from, vpsData, theme) {
  const { host, port, username, password } = vpsData;
  const themeName = theme.name;
  const themeUrl = theme.url;
  const isNebula = themeName.toLowerCase() === "nebula";
  const isBlueprint = theme.type === "blueprint";

  try {
    await bot.sendMessage(chatId, "🔌 Menghubungkan ke VPS...");
    // Test login sederhana
    await runSSHScript({ host, port, username, password }, "echo 'OK LOGIN'");

    await bot.sendMessage(chatId, "✅ Login berhasil.\n");

    if (isBlueprint && isNebula) {
      await bot.sendMessage(chatId, "📦 Menginstall dependensi Blueprint (install_depend)...");
      const depsScript = buildBlueprintDepsScript();
      await runSSHScript({ host, port, username, password }, depsScript);

      await bot.sendMessage(chatId, "✅ Dependensi Blueprint selesai.\n✨ Sedang menginstall tema Nebula (Blueprint)...");

      const nebulaScript = buildBlueprintThemeScript(themeName, themeUrl);
      await runSSHScript({ host, port, username, password }, nebulaScript);

      await bot.sendMessage(chatId, "🎉 Tema Nebula berhasil diinstall tanpa kendala!");
    } else if (isBlueprint) {
      await bot.sendMessage(chatId, `✨ Sedang menginstall tema ${themeName} (Blueprint)...`);
      const blueprintScript = buildBlueprintThemeScript(themeName, themeUrl);
      await runSSHScript({ host, port, username, password }, blueprintScript);
      await bot.sendMessage(chatId, `🎉 Tema ${themeName} berhasil diinstall!`);
    } else {
      await bot.sendMessage(chatId, `✨ Sedang menginstall tema ${themeName} (manual)...\nProses ini bisa memakan waktu beberapa menit, tergantung VPS.`);
      const manualScript = buildManualThemeScript(themeName, themeUrl);
      await runSSHScript({ host, port, username, password }, manualScript);
      await bot.sendMessage(chatId, `🎉 Tema ${themeName} berhasil diinstall!`);
    }
  } catch (err) {
    console.error("[/installtema] SSH error:", err?.message);
    const msg = String(err?.message || err || "Unknown error").slice(0, 500);
    await bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat instalasi tema.\nPesan VPS:\n<pre><code>" + escapeHtml(msg) + "</code></pre>",
      { parse_mode: "HTML" }
    );
  }
}

function backKeyboard(){ return { inline_keyboard: [[{ text: "⬅️ Kembali", callback_data: "MENU" }]] }; }
function buildRamKeyboard(username) {
  const rows = [];
  const hargaDasar = config.HARGA_PANEL || 1000;
  rows.push([{ text: `Unlimited • Rp${formatRupiah(hargaDasar*10)}`, callback_data: `BUYRAM:unlimited|${username}` }]);
  for (const opt of RAM_OPTIONS.filter(o=>!o.unlimited)) {
    const base = hargaDasar * parseInt(opt.label);
    rows.push([{ text: `${opt.label} • Rp${formatRupiah(base)}`, callback_data: `BUYRAM:${opt.key}|${username}` }]);
  }
  rows.push([{ text: "⬅️ Kembali", callback_data: "MENU" }]);
  return { inline_keyboard: rows };
}
function productTypeKeyboard(username){
  return {
    inline_keyboard: [
      [{ text: "⚙️ Panel RAM", callback_data: `CHOOSE_RAM:${username}` }],
      [{ text: "🛡️ Admin Panel", callback_data: `BUYADP:${username}` }],
      [{ text: "⬅️ Kembali", callback_data: "MENU" }]
    ]
  };
}

async function generateQcSticker(bot, chatId, from, colorKey, messageText, replyToMessageId) {
  const backgroundColor = QC_COLOR_MAP[colorKey] || "#ffffff";

  // Avatar default
  let avatarUrl = "https://telegra.ph/file/c3f3d2c2548cbefef1604.jpg";

  try {
    // Coba pakai foto profil Telegram user -> upload ke Catbox
    const photos = await bot.getUserProfilePhotos(from.id, { limit: 1 });
    if (photos.total_count && photos.photos && photos.photos[0] && photos.photos[0][0]) {
      const fileId = photos.photos[0][0].file_id;
      const buf = await downloadTelegramFile(bot, fileId);
      avatarUrl = await uploadToCatbox(buf, "avatar.jpg");
    }
  } catch (e) {
    console.error("[QC avatar error]", e);
  }

  const json = {
    type: "quote",
    format: "png",
    backgroundColor,
    width: 700,
    height: 580,
    scale: 2,
    messages: [{
      entities: [],
      avatar: true,
      from: {
        id: from.id,
        name: from.first_name || from.username || "User",
        photo: { url: avatarUrl }
      },
      text: messageText,
      "m.replyMessage": {}
    }]
  };

  try {
    await bot.sendChatAction(chatId, "upload_photo");
    const res = await axios.post("https://bot.lyo.su/quote/generate", json, {
      headers: { "Content-Type": "application/json" },
      timeout: 60000
    });
    const qc = Buffer.from(res.data.result.image, "base64");
    await bot.sendSticker(chatId, qc, { reply_to_message_id: replyToMessageId });
  } catch (error) {
    console.error("Error generating QC v1:", error);
    try {
      const data = await axios.post("https://bot.lyo.su/quote/generate", json, {
        headers: { "Content-Type": "application/json" },
        timeout: 60000
      });
      const qc = Buffer.from(data.data.result.image, "base64");
      await bot.sendSticker(chatId, qc, { reply_to_message_id: replyToMessageId });
    } catch (e) {
      console.error("Error generating QC v2:", e);
      await bot.sendMessage(chatId, "Server Create Sedang Offline!", {
        reply_to_message_id: replyToMessageId
      });
    }
  }
}

async function sendStartMenu(bot, chatId, from) {
  const isOwner = from.id === config.OWNER_ID;
  const thumbPath = path.join(__dirname, "thumb.jpg");

  const caption = [
  "<blockquote>Alpha Centauri by @Yopandelreyz",
  "",
  "✨<b>Selamat datang di Alpha Centauri</b>",
  "🤖Solusi Server Panel Awet untuk kebutuhan Bot Anda.",
  "",
  "👨‍💻<code><b>Developer:</b> @Yopandelreyz</code>",
  "📝 <b>Bahasa:</b> JavaScript",
  "⚙️ <b>Versi:</b> 4.5.0 Premier",
  "",
  "🚀<b>Keunggulan:</b>",
  "⚡<code>Script ringan dan stabil",
  "📐 Intergrasi pakasir",
  "🛍️ Pembelian produk otomatis",
  "🛡️ Keamanan sistem DB",
  "🔄 Sering Update dari dev</code>",
  "",
  "📊<b>Tambahan:</b>",
  "🧩 Harga Script Murah Rp: <span class=\"tg-spoiler\">15.000</span>",
  "💡 Free Update Dari Developer",
  "",
  "🛒<b>Tertarik? Chat sekarang untuk konsultasi atau langsung order!</b></blockquote>",
].join("\n");


  if (fs.existsSync(thumbPath)) {
    await bot.sendPhoto(chatId, thumbPath, {
      caption,
      parse_mode: "HTML",
      reply_markup: mainMenuKeyboard(isOwner)
    });
  } else {
    await bot.sendMessage(chatId, caption, {
      parse_mode: "HTML",
      reply_markup: mainMenuKeyboard(isOwner)
    });
  }
}

// ===== Alias untuk tombol reply keyboard =====
bot.onText(/^belipanel$/i, async (msg) => {
  // sama seperti /buypanel tanpa username -> tanya username
  await askUsername(bot, msg.chat.id);
});

bot.onText(/^buyresseler$/i, async (msg) => {
  const chatId = msg.chat.id;
  const from = msg.from;
  await askResellerId(bot, chatId, from);
});

bot.onText(/^beliadmin\s*panel$/i, async (msg) => {
  const chatId = msg.chat.id;
  const chat = await bot.getChat(chatId);
  if (["group", "supergroup"].includes(chat.type)) {
    return bot.sendMessage(
      chatId,
      "Fitur pembelian tidak tersedia di grup. Silakan chat <b>private</b> dengan bot.",
      { parse_mode: "HTML" }
    );
  }
  // arahkan user pakai /buyadp
  return bot.sendMessage(
    chatId,
    "Masukan username\n*Contoh :* /buyadp skyzopedia",
    { parse_mode: "Markdown" }
  );
});

bot.onText(/^list\s*produk$/i, async (msg) => {
  await showProductList(bot, msg.chat.id);
});

// alias typo: /buyresseler
bot.onText(/^\/buyresseler\s*(.*)$/i, async (msg, match) => {
  const chatId = msg.chat.id; const from = msg.from;
  const maybeId = (match[1] || "").trim();
  if (!maybeId) return askResellerId(bot, chatId, from);
  const idNum = parseInt(maybeId.replace(/[^0-9]/g, ""), 10);
  if (!idNum) return bot.sendMessage(chatId, "ID Telegram tidak valid. Ketik /cekidch untuk melihat ID kamu.");
  await startBuyReseller(bot, chatId, from, idNum);
});

function buildScriptList() { const db = loadDB(); return db.settings.script || []; }
async function showScriptListForPurchase(bot, chatId) {
  const list = buildScriptList();
  if (!list.length) return bot.sendMessage(chatId, "Tidak ada script yang tersedia untuk dijual.");
  let teks = "Pilih Script Bot WhatsApp\n";
  const kb = { inline_keyboard: [
    ...list.map((it, idx) => [{ text: `${it.nama} • Rp${formatRupiah(it.harga)}`.slice(0, 64), callback_data: `BUYSC_IDX:${idx}` }]),
    [{ text: "⬅️ Kembali", callback_data: "MENU" }]
  ]};
  return bot.sendMessage(chatId, teks, { reply_markup: kb });
}

function buildProductList() {
  const db = loadDB();
  return (db.settings && Array.isArray(db.settings.products))
    ? db.settings.products
    : [];
}

async function showPanelAdminMenu(bot, chatId) {
  const kb = {
    inline_keyboard: [
      [{ text: "🛡️ Admin Panel", callback_data: "CHOOSE_ADP" }],
      [{ text: "⚙️ Panel Server", callback_data: "CHOOSE_PANEL_SERVER" }],
      [{ text: "⬅️ Kembali", callback_data: "MENU" }]
    ]
  };
  await bot.sendMessage(chatId, "Pilih jenis panel:", { reply_markup: kb });
}

async function askUsernameFor(bot, chatId, mode) {
  const label = mode === "admin" ? "Admin Panel" : "Panel Server";
  const prompt = `Masukkan <b>username ${label}</b> (tanpa spasi). Contoh: <code>Yopandelreyz</code>`;
  await bot.sendMessage(chatId, prompt, { parse_mode: "HTML", reply_markup: { force_reply: true } });
}

async function askUsername(bot, chatId) {
  await bot.sendMessage(chatId, "Contoh: <code>/buypanel</code> namalu <b>DISITU NANTI ADA PILIHAN MAU ADP ATAU PANEL SERVER YA ANAK KUCAI</b>", {
    parse_mode: "HTML",
    reply_markup: { force_reply: true }
  });
}
async function sendTypeSelection(bot, chatId, username) {
  const txt = `Pilih produk untuk username <code>${username}</code>`;
  await bot.sendMessage(chatId, txt, { parse_mode: "HTML", reply_markup: productTypeKeyboard(username) });
}
async function sendRamOptions(bot, chatId, username) {
  const text = `Pilih <b>RAM</b> untuk username <code>${username}</code>`;
  await bot.sendMessage(chatId, text, { parse_mode: "HTML", reply_markup: buildRamKeyboard(username) });
}

async function createQrisAndSend(bot, chatId, from, { orderId, amount, captionLines, onCompleted, variant, context }) {
  const loading = await bot.sendMessage(chatId, "⏳ Sedang membuat QRIS, mohon ditunggu...");
  try {
    await bot.sendChatAction(chatId, "upload_photo");
    const payment = await pakasir.createQris({ amount, orderId });
    const qrString = payment.payment_number;
    const pngBuffer = await QRCode.toBuffer(qrString, { width: 700, errorCorrectionLevel: "M" });

    const caption = captionLines.join("\n");
    try { await bot.deleteMessage(chatId, loading.message_id); } catch {}

    const keyboard = { inline_keyboard: [
      [{ text: "🔄 Refresh Status", callback_data: `CEK:${orderId}:${amount}` }],
      [{ text: "❌ Batalkan Pembelian", callback_data: "CANCEL" }],
      [{ text: "⬅️ Kembali", callback_data: "MENU" }]
    ]};

    const msgQr = await bot.sendPhoto(
      chatId,
      pngBuffer,
      { caption, parse_mode: "Markdown", reply_markup: keyboard },
      { filename: "qris.png", contentType: "image/png" }
    );

    const expTimeout = setTimeout(async () => {
      const t = dbTransaksi.get(from.id);
      if (t && t.status) {
        await bot.sendMessage(chatId, "⚠️ QRIS Pembayaran Telah Expired. Transaksi Dibatalkan!", { reply_markup: backKeyboard() });
        try { await bot.deleteMessage(chatId, msgQr.message_id); } catch {}
        dbTransaksi.delete(from.id);
      }
    }, 5 * 60 * 1000);

    dbTransaksi.set(from.id, { status: true, msg: msgQr, chat: chatId, idDeposit: orderId, amount: String(amount), variant, context, expTimeout });
    
    if (!activeCheckers.has(orderId)) {
      const timer = setInterval(async () => {
        const t = dbTransaksi.get(from.id);
        if (!t || !t.status) { clearInterval(timer); activeCheckers.delete(orderId); return; }
        try {
          const trx = await pakasir.getTransactionDetail({ amount, orderId });
          if (trx.status && String(trx.status).toLowerCase() === "completed") {
            clearInterval(timer); activeCheckers.delete(orderId);
            await onCompleted(bot, from.id);
          }
        } catch (e) {}
      }, 7000);
      activeCheckers.set(orderId, timer);
    }
  } catch (err) {
    try { await bot.editMessageText("❌ Gagal membuat QRIS. " + (err.message || ""), { chat_id: chatId, message_id: loading.message_id }); } catch {}
      console.error("createQris error:", err?.response?.data || err?.message || err);
  }
}

async function onPanelPaid(bot, userId) {
  const t = dbTransaksi.get(userId);
  if (!t) return;

  t.status = false;
  try { clearTimeout(t.expTimeout); } catch {}

  const { chat, msg, idDeposit, amount, context } = t;
  const { username, planKey, res, isAdmin } = context;

  const email = `${username}@gmail.com`;
  const name = capital(username) + (isAdmin ? " AdminPanel" : " Server");
  const password = username + "001";

  try {
    // Buat user + server via ptero (punyamu sudah benar)
    const user = await ptero.createUser({
  email,
    username: username.toLowerCase(),
    first_name: name,
    last_name: isAdmin ? "Adp" : "Server",
    password,
    root_admin: isAdmin ? true : false
   });


    const featureLimits = isAdmin
      ? { databases: 10, backups: 10, allocations: 10 }
      : { databases: 5, backups: 5, allocations: 5 };

    const server = await ptero.createServer({
      name,
      description: tanggal(Date.now()),
      userId: user.id,
      ram: parseInt(res.ram),
      disk: parseInt(res.disk),
      cpu: parseInt(res.cpu),
      featureLimits
    });

    const lines = [];
    lines.push("*PEMBAYARAN BERHASIL ✅*", "");
    lines.push(`- ID: *${idDeposit}*`);
    lines.push(`- Total: *Rp${formatRupiah(Number(amount))}*`);
    lines.push(`- Barang: *${isAdmin ? "Admin Panel Pterodactyl" : "Panel Pterodactyl (" + (planKey === 'unlimited' ? 'Unlimited' : planKey.toUpperCase()) + ")*"}`);
    lines.push(`- Username: *${username}*`, "");
    lines.push("*Berikut detail akun kamu*", "");
    lines.push(`📡 Server ID: ${server.id}`);
    lines.push(`👤 Username: \`${user.username}\``);
    lines.push(`🔐 Password: \`${password}\``);
    lines.push(`🗓️ Aktivasi: ${tanggal(Date.now())}`, "", "⚙️ *Spesifikasi*");
    lines.push(`- RAM: ${res.ram === "0" ? "Unlimited" : (parseInt(res.ram)/1000) + "GB"}`);
    lines.push(`- DISK: ${res.disk === "0" ? "Unlimited" : (parseInt(res.disk)/1000) + "GB"}`);
    lines.push(`- CPU: ${res.cpu === "0" ? "Unlimited" : res.cpu + "%"}`);
    lines.push(`- ${config.PTERO_DOMAIN}`);

    const kb = {
      inline_keyboard: [
        [{ text: "🔑 Login Panel", url: config.PTERO_DOMAIN }],
        [{ text: "⬅️ Kembali", callback_data: "MENU" }]
      ]
    };

    await bot.sendMessage(chat, lines.join("\n"), { reply_markup: kb });
    try { await bot.deleteMessage(chat, msg.message_id); } catch {}

  } catch (e) {
    // PENTING: pakai 'chat', bukan 'chatId', dan kirim error dengan HTML aman
    await sendSafeError(
      bot,
      chat,
      "Pembayaran berhasil, namun pembuatan Admin Panel gagal. Admin akan membantu manual.",
      e
    );

  } finally {
    dbTransaksi.delete(userId);
  }
}

async function startPanelRam(bot, chatId, from, username, planKey) {
  const chat = await bot.getChat(chatId);
  if (["group","supergroup"].includes(chat.type)) return bot.sendMessage(chatId, "Fitur pembelian tidak tersedia di grup. Silakan chat <b>private</b> dengan bot.", { parse_mode: "HTML" });
  if (dbTransaksi.get(from.id)) return bot.sendMessage(chatId, "Masih ada transaksi yang belum diselesaikan. Ketik <code>/batalbeli</code> untuk membatalkan.", { parse_mode: "HTML" });

  const opt = RAM_OPTIONS.find(o => o.key === planKey);
  if (!opt) return bot.sendMessage(chatId, "Pilihan RAM tidak valid!", { reply_markup: backKeyboard() });

  const hargaDasar = config.HARGA_PANEL || 1000;
  const basePrice = opt.unlimited ? hargaDasar*10 : hargaDasar * parseInt(opt.label);
  const amount = basePrice + rand(config.UNIQUE_MIN, config.UNIQUE_MAX);
  const res = { ram: String(opt.ram), disk: String(opt.disk), cpu: String(opt.cpu) };
  const orderId = `TG-${from.id}-${Date.now()}`;
  const captionLines = ["*INFORMASI PEMBAYARAN*","",`- Order ID: *${orderId}*`,`- Total Pembayaran: *Rp${formatRupiah(amount)}*`,`- Barang: *Panel Pterodactyl (${opt.unlimited?"Unlimited":opt.label})*`,`- Username: *${username}*`,`- Expired QRIS: *5 menit*`];

  return createQrisAndSend(bot, chatId, from, { orderId, amount, captionLines, variant: "panel", context: { username, planKey, res, isAdmin: false }, onCompleted: onPanelPaid });
}

async function startAdminPanel(bot, chatId, from, username) {
  const chat = await bot.getChat(chatId);
  if (["group","supergroup"].includes(chat.type)) return bot.sendMessage(chatId, "Fitur pembelian tidak tersedia di grup. Silakan chat <b>private</b> dengan bot.", { parse_mode: "HTML" });
  if (dbTransaksi.get(from.id)) return bot.sendMessage(chatId, "Masih ada transaksi yang belum diselesaikan. Ketik <code>/batalbeli</code> untuk membatalkan.", { parse_mode: "HTML" });

  const basePrice = (config.HARGA_ADP || 10000);
  const amount = basePrice + rand(config.UNIQUE_MIN, config.UNIQUE_MAX);
  const orderId = `ADP-${from.id}-${Date.now()}`;
  const res = { ram: "0", disk: "0", cpu: "0" };
  const captionLines = ["*INFORMASI PEMBAYARAN*","",`- Order ID: *${orderId}*`,`- Total Pembayaran: *Rp${formatRupiah(amount)}*`,`- Barang: *Admin Panel Pterodactyl*`,`- Username: *${username}*`,`- Expired QRIS: *5 menit*`];

  return createQrisAndSend(bot, chatId, from, { orderId, amount, captionLines, variant: "panel", context: { username, planKey: "unlimited", res, isAdmin: true }, onCompleted: onPanelPaid });
}

async function startBuyScript(bot, chatId, from, scriptIndexOrPath) {
  const chat = await bot.getChat(chatId);
  if (["group","supergroup"].includes(chat.type)) return bot.sendMessage(chatId, "Fitur pembelian tidak tersedia di grup. Silakan chat <b>private</b> dengan bot.", { parse_mode: "HTML" });
  const db = loadDB();
  if (dbTransaksi.get(from.id)) return bot.sendMessage(chatId, "Masih ada transaksi yang belum diselesaikan. Ketik <code>/batalbeli</code> untuk membatalkan transaksi sebelumnya.", { parse_mode: "HTML" });
  const scripts = db.settings.script || [];
  if (!scripts.length) return bot.sendMessage(chatId, "Tidak ada script yang tersedia untuk dijual.");

  let sc = null;
  if (typeof scriptIndexOrPath === "number") sc = scripts[scriptIndexOrPath] || null;
  else if (typeof scriptIndexOrPath === "string") sc = scripts.find(i => i.path === scriptIndexOrPath) || null;
  if (!sc) return bot.sendMessage(chatId, "Script tidak ditemukan di database.");

  const harga = Number(sc.harga) + rand(100, 250);
  const orderId = `SC-${from.id}-${Date.now()}`;
  const captionLines = ["*INFORMASI PEMBAYARAN*","",`- Order ID: *${orderId}*`,`- Total Pembayaran: *Rp${formatRupiah(harga)}*`,`- Barang: *${sc.nama}*`,`- Expired QRIS: *5 menit*`];

  return createQrisAndSend(bot, chatId, from, { orderId, amount: harga, captionLines, variant: "script", context: { targetFile: sc.path, nama: sc.nama }, onCompleted: onScriptPaid });
}

function listScripts(bot, chatId) {
  const db = loadDB();
  const scripts = db.settings.script || [];
  if (!scripts.length) return bot.sendMessage(chatId, "Tidak Ada Script Bot Tersimpan.");
  let teks = "";
  scripts.forEach((it) => { const harga = formatRupiah(Number(it.harga || 0)); teks += `\n- Nama: *${it.nama}*\n- Harga: *Rp${harga}*\n`; });
  const keyboard = { inline_keyboard: [ ...scripts.map((it, idx) => [{ text: `🗑️ Hapus: ${it.nama}`.slice(0,60), callback_data: `DELSC_IDX:${idx}` }]), [{ text: "⬅️ Kembali", callback_data: "MENU" }] ] };
  return bot.sendMessage(chatId, teks || "-", { parse_mode: "Markdown", reply_markup: keyboard });
}

async function showDeleteProducts(bot, chatId) {
  const db = loadDB();
  const list = db.settings.products || [];
  if (!list.length) return bot.sendMessage(chatId, "Belum ada produk yang bisa dihapus.", { reply_markup: backKeyboard() });

  let teks = "🗑️ <b>Hapus Produk (Owner)</b>\n\nPilih produk yang ingin dihapus:";
  const rows = [];
  list.forEach((p, i) => {
    const h = Number(p.harga || 0);
    const hargaFmt = new Intl.NumberFormat('id-ID').format(h);
    rows.push([{ text: `${p.nama} (Rp${hargaFmt})`, callback_data: `DELPROD_IDX:${i}` }]);
  });
  rows.push([{ text: "⬅️ Kembali", callback_data: "MENU" }]);

  await bot.sendMessage(chatId, teks, { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
}

async function deleteProductByIndex(bot, chatId, idx) {
  const db = loadDB();
  const arr = db.settings.products || [];
  if (isNaN(idx) || !arr[idx]) {
    return bot.sendMessage(chatId, "Produk tidak ditemukan.", { reply_markup: backKeyboard() });
  }

  const item = arr[idx];

  // Hapus file zip jika tipe file
  if (item.type === "file" && item.path) {
    try { fs.unlinkSync(item.path); } catch {}
  }

  // Hapus dari database.json
  arr.splice(idx, 1);
  saveDB(db);

  await bot.sendMessage(
    chatId,
    `✅ Produk *${item.nama}* berhasil dihapus.`,
    { parse_mode: "Markdown", reply_markup: backKeyboard() }
  );

  // Tampilkan lagi daftar untuk memudahkan hapus banyak
  await showDeleteProducts(bot, chatId);
}

// === Deposit (Owner): minta nominal ===
function askDepositAmount(bot, chatId, from) {
  if (from.id !== config.OWNER_ID) {
    return bot.sendMessage(chatId, "Menu ini khusus owner.", { reply_markup: backKeyboard() });
  }
  // tandai menunggu input nominal
  depositPrompt.set(from.id, true);
  const teks = [
    "<b>Deposit (Owner)</b>",
    "Silakan ketik nominal deposit kamu.",
    "• Minimal: <b>500</b>",
    "• Maksimal: <b>300000</b>",
    "",
    "Contoh: <code>75000</code>"
  ].join("\n");
  return bot.sendMessage(chatId, teks, { parse_mode: "HTML", reply_markup: { force_reply: true } });
}

async function startOwnerDeposit(bot, chatId, from, nominal) {
  if (from.id !== config.OWNER_ID) {
    return bot.sendMessage(chatId, "Menu ini khusus owner.", { reply_markup: backKeyboard() });
  }
  if (dbTransaksi.get(from.id)) {
    return bot.sendMessage(chatId, "Masih ada transaksi berjalan. Ketik /batalbeli untuk membatalkan.");
  }

  const base = Number(nominal || 0);
  // Tambah unik code seperti fitur lain
  const amount = base + rand(config.UNIQUE_MIN, config.UNIQUE_MAX);
  const orderId = `DEP-${from.id}-${Date.now()}`;
  const captionLines = [
    "*DEPOSIT (OWNER)*",
    "",
    `- Order ID: *${orderId}*`,
    `- Nominal: *Rp${new Intl.NumberFormat('id-ID').format(base)}*`,
    `- Total Bayar: *Rp${new Intl.NumberFormat('id-ID').format(amount)}*`,
    `- Expired QRIS: *5 menit*`
  ];

  return createQrisAndSend(bot, chatId, from, {
    orderId,
    amount,
    captionLines,
    onCompleted: onOwnerDepositPaid,
    variant: "deposit",
    context: { base },
    loadingText: "Sedang membuat QRIS deposit..."
  });
}

async function onOwnerDepositPaid(bot, userId) {
  const t = dbTransaksi.get(userId);
  if (!t) return;
  t.status = false; try { clearTimeout(t.expTimeout); } catch {}
  const { chat, amount, context } = t;
  const base = Number(context?.base || 0);

  const db = loadDB();
  db.deposits.push({
    order_id: t.orderId || t.idDeposit || `DEP-${userId}`,
    owner_id: userId,
    base_amount: base,
    paid_amount: Number(amount || 0),
    created_at: new Date().toISOString()
  });
  saveDB(db);

  const owner = config.OWNER_ID;
  try {
    await bot.sendMessage(owner, [
      "💳 <b>Deposit Owner (PAID)</b>",
      `• Nominal: <b>Rp${new Intl.NumberFormat('id-ID').format(base)}</b>`,
      `• Total Bayar: <b>Rp${new Intl.NumberFormat('id-ID').format(Number(amount || 0))}</b>`,
      `• Waktu: ${new Date().toLocaleString('id-ID')}`
    ].join("\n"), { parse_mode: "HTML" });
  } catch {}

  await bot.sendMessage(chat, [
    "✅ *Deposit Berhasil*",
    "",
    `- Nominal: *Rp${new Intl.NumberFormat('id-ID').format(base)}*`,
    `- Total Bayar: *Rp${new Intl.NumberFormat('id-ID').format(Number(amount || 0))}*`
  ].join("\n"), { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "⬅️ Kembali", callback_data: "MENU" }]] } });

  dbTransaksi.delete(userId);
}

bot.setMyCommands([
  { command: "start", description: "Buka menu utama" },
  { command: "menu", description: "Menu ringkas" },

  { command: "buypanel", description: "Beli Panel (username lalu pilih paket)" },
  { command: "buyadp", description: "Beli Admin Panel (username)" },

  { command: "cekidch", description: "Cek ID Telegram kamu" },
  { command: "buyreseller", description: "Beli reseller (isi ID Telegram)" },
  { command: "listproduk", description: "Daftar produk" },
  { command: "addproduk", description: "(Owner) Tambah produk" },

  { command: "batalbeli", description: "Batalkan transaksi berjalan" },
  { command: "alphaai", description: "Aktif/nonaktif AI chat" },
  { command: "struk", description: "Buat struk pembayaran" },
  { command: "spotify", description: "Cari lagu Spotify" },
  { command: "spdown", description: "Download lagu dari URL Spotify" },
  { command: "tiktok", description: "Download video TikTok" },
  { command: "sora2", description: "Generate video AI (Sora2)" },
  { command: "report", description: "Laporkan bug ke owner" },
  { command: "req", description: "Request fitur baru" },
  { command: "bcs", description: "(Owner) Broadcast ke semua user" },
  { command: "enchard", description: "Owner: encrypt JS" },
  { command: "done", description: "(Owner) Post transaksi selesai" },
  { command: "proses", description: "(Owner) Konfirmasi dana diterima" },
  { command: "payment", description: "(Owner) Tampilkan QRIS & nomor e-wallet" },
  { command: "tourl", description: "Upload media jadi URL (reply media)" },
  { command: "tourl2", description: "Upload foto jadi URL (reply foto)" },
  { command: "backupsc", description: "(Owner) Backup script (ZIP)" },
  { command: "addprotectpanel", description: "(Owner) Pasang proteksi panel via SSH)" },
  { command: "installtema", description: "Install tema panel via SSH" },
  { command: "installpanel", description: "Install panel via SSH" },
  { command: "iqc", description: "(Owner) Fake iPhone Chat image" },
  { command: "allmenu", description: "Melihat semua perintah bot" },
  { command: "qc", description: "Membuat Sticker Quote" },
]).catch(() => {});

  bot.onText(/\/?start/, async (msg) => {
    const chatId = msg.chat.id; const from = msg.from;
    const db = loadDB(); addUserIfNotExists(db, from); touchUser(db, from.id);
    await sendStartMenu(bot, chatId, from);
  });

  bot.onText(/\/batalbeli/, async (msg) => {
    const t = dbTransaksi.get(msg.from.id);
    if (!t) return bot.sendMessage(msg.chat.id, "Tidak ada transaksi aktif.");
    try { clearTimeout(t.expTimeout); } catch {}
    try { await bot.deleteMessage(t.chat, t.msg.message_id); } catch {}
    dbTransaksi.delete(msg.from.id);
    await bot.sendMessage(msg.chat.id, "Transaksi dibatalkan.");
  });

  bot.onText(/^\/buypanel\s*(.*)$/i, async (msg, match) => {
    const chatId = msg.chat.id; const from = msg.from;
    const chat = await bot.getChat(chatId);
    if (["group","supergroup"].includes(chat.type)) return bot.sendMessage(chatId, "Fitur pembelian tidak tersedia di grup. Silakan chat <b>private</b> dengan bot.", { parse_mode: "HTML" });
    const username = (match[1] || "").trim().toLowerCase();
    if (!username || username.split(" ").length>1) return askUsername(bot, chatId);
    await sendTypeSelection(bot, chatId, username);
  });

  // Handler ForceReply: nominal deposit owner
bot.on("message", async (msg) => {
  const from = msg.from; const chatId = msg.chat.id;
  if (!depositPrompt.get(from.id)) return;
  const raw = (msg.text || "").trim();
  const val = parseInt(raw.replace(/[^0-9]/g, ""), 10);
  if (!val || isNaN(val)) {
    return bot.sendMessage(chatId, "Nominal tidak valid. Ketik angka saja.", { reply_markup: backKeyboard() });
  }
  if (val <  500 || val > 300000) {
    return bot.sendMessage(chatId, "Batas nominal: minimal 500 dan maksimal 300000.", { reply_markup: backKeyboard() });
  }
  depositPrompt.delete(from.id);
  await startOwnerDeposit(bot, chatId, from, val);

});

    // Lightweight handler for copy e-wallet alerts
  bot.on("callback_query", async (query) => {
    try {
      const data = query.data || "";

      // Copy nomor e-wallet (DANA / OVO / GOPAY)
      if (data === "COPY_DANA" || data === "COPY_OVO" || data === "COPY_GOPAY") {
        const map = { COPY_DANA: config.dana || "-", COPY_OVO: config.ovo || "-", COPY_GOPAY: config.gopay || "-" };
        return bot.answerCallbackQuery(query.id, { text: map[data], show_alert: true });
      }

      // Inline copy callback handler (for COPY_* and COPY_URL:*)
      if (data.startsWith("COPY_URL:")) {
        const id = data.split(":")[1];
        const val = (global.__copyStore && global.__copyStore.get(id)) || "URL kadaluarsa.";
        return bot.answerCallbackQuery(query.id, { text: val, show_alert: true });
      }
    } catch (e) {
      console.error("callback copy handler err:", e);
    }
  });

  // ===== /allmenu — Tampilkan semua command bot =====
  bot.onText(/^\/allmenu$/i, async (msg) => {
    const chatId = msg.chat.id;
    const from = msg.from;

    const commands = [
      { command: "start", description: "Buka menu utama" },
      { command: "menu", description: "Menu ringkas" },
      { command: "allmenu", description: "Lihat semua perintah & fitur" },

      { command: "buypanel", description: "Beli Panel (username lalu pilih paket)" },
      { command: "buyadp", description: "Beli Admin Panel (username)" },

      { command: "cekidch", description: "Cek ID Telegram kamu" },
      { command: "buyreseller", description: "Beli reseller (isi ID Telegram)" },
      { command: "listproduk", description: "Daftar produk" },
      { command: "addproduk", description: "(Owner) Tambah produk" },

      { command: "batalbeli", description: "Batalkan transaksi berjalan" },
      { command: "alphaai", description: "Aktif/nonaktif AI chat" },
      { command: "struk", description: "Buat struk pembayaran" },
      { command: "spotify", description: "Cari lagu Spotify" },
      { command: "spdown", description: "Download lagu dari URL Spotify" },
      { command: "tiktok", description: "Download video TikTok" },
      { command: "sora2", description: "Generate video AI (Sora2)" },
      { command: "report", description: "Laporkan bug ke owner" },
      { command: "req", description: "Request fitur baru" },
      { command: "bcs", description: "(Owner) Broadcast ke semua user" },
      { command: "enchard", description: "Owner: encrypt JS" },
      { command: "done", description: "(Owner) Post transaksi selesai" },
      { command: "proses", description: "(Owner) Konfirmasi dana diterima" },
      { command: "payment", description: "(Owner) Tampilkan QRIS & nomor e-wallet" },
      { command: "tourl", description: "Upload media jadi URL (reply media)" },
      { command: "tourl2", description: "Upload foto jadi URL (reply foto)" },
      { command: "backupsc", description: "(Owner) Backup script (ZIP)" },
      { command: "addprotectpanel", description: "(Owner) Pasang proteksi panel via SSH)" },
      { command: "installtema", description: "Install tema panel via SSH" },
      { command: "installpanel", description: "Install panel via SSH" },
      { command: "startwings", description: "(Owner) Menjalankan wings node Pterodactyl via SSH" },
        
      { command: "iqc", description: "(Owner) Fake iPhone Chat image" },
      { command: "qc", description: "Membuat Sticker Quote" },
    ];

    const namaToko = config.NAMA_TOKO || "Alpha Centauri";
    const firstName = from.first_name || "User";

    const lines = [];
    // 1) <blockquote>
    lines.push("<blockquote><b>Alpha Centauri — All Menu</b></blockquote>");
    // 2) <b>
    lines.push(`<b>Hai ${escapeHtml(firstName)}!</b>`);
    lines.push(
      `Berikut daftar lengkap perintah yang bisa kamu pakai di <b>${escapeHtml(namaToko)}</b>.`
    );
    lines.push("");
    // 3) <code>
    lines.push("<code>Tip:</code> Klik atau ketik perintah di bawah ini untuk menjalankan fitur.");
    lines.push("");
    lines.push("📖 <b>Daftar Perintah:</b>");
    lines.push("");

    commands.forEach((c) => {
      lines.push(`/<b>${c.command}</b> — ${escapeHtml(c.description)}`);
    });

    lines.push("");
    lines.push(
      "<i>Gunakan menu ini sebagai panduan cepat. Kalau bingung, kirim /start untuk kembali ke menu utama.</i>"
    );

    const caption = lines.join("\n");

    const thumbAllMenu = path.join(__dirname, "thumb2.jpg");

    try {
      if (fs.existsSync(thumbAllMenu)) {
        await bot.sendPhoto(chatId, thumbAllMenu, {
          caption,
          parse_mode: "HTML",
        });
      } else {
        // fallback kalau gambar belum ada
        await bot.sendMessage(chatId, caption, {
          parse_mode: "HTML",
        });
      }
    } catch (e) {
      console.error("[/allmenu] error:", e?.message || e);
      await bot.sendMessage(
        chatId,
        "❌ Terjadi kesalahan saat mengirim menu. Coba lagi beberapa saat.",
        { parse_mode: "HTML" }
      );
    }
  });

bot.onText(/^\/(buyadp|buyadminpanel)\s*(.*)$/i, async (msg, match) => {
    const chatId = msg.chat.id; const from = msg.from;
    const chat = await bot.getChat(chatId);
    if (["group","supergroup"].includes(chat.type)) return bot.sendMessage(chatId, "Fitur pembelian tidak tersedia di grup. Silakan chat <b>private</b> dengan bot.", { parse_mode: "HTML" });
    const username = (match[2] || "").trim().toLowerCase();
    if (!username || username.split(" ").length>1) return bot.sendMessage(chatId, "Masukan username\n*Contoh :* /buyadp skyzopedia", { parse_mode: "Markdown" });
    await startAdminPanel(bot, chatId, from, username);
  });
  
  bot.onText(/^\/bcs\s+([\s\S]+)/i, async (msg, match) => {
    const from = msg.from;
    if (from.id !== config.OWNER_ID) return bot.sendMessage(msg.chat.id, "Perintah ini khusus owner.", { reply_markup: backKeyboard() });
    const text = match[1].trim();
    const db = loadDB(); const users = db.users || [];
    let ok = 0, fail = 0;
    for (const u of users) { try { await bot.sendMessage(u.id, text); ok++; } catch { fail++; } }
    db.broadcasts.push({ text, by: from.id, at: new Date().toISOString(), delivered: ok, failed: fail }); saveDB(db);
    await bot.sendMessage(msg.chat.id, `Broadcast dikirim. Berhasil: ${ok}, Gagal: ${fail}`, { reply_markup: backKeyboard() });
  });

  
  // ===================== /bcs (broadcast ke semua user) =======================
  bot.onText(/^\/bcs\b(?:\s+([\s\S]+))?/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const from   = msg.from;

    if (!config.OWNER_ID || Number(config.OWNER_ID) !== from.id) {
      return bot.sendMessage(chatId, "Perintah ini khusus owner.", {
        reply_to_message_id: msg.message_id
      });
    }

    const db = loadDB();
    const users = (db.users || []).map(u => u.id).filter(id => id && id !== from.id);

    if (!users.length) {
      return bot.sendMessage(chatId, "Belum ada user yang terdaftar untuk broadcast.");
    }

    const extraText = (match[1] || "").trim();
    const reply = msg.reply_to_message;

    let mode = "";
    let sendToOne;

    if (reply) {
      // Broadcast pesan yang di-reply (foto/dokumen/teks/suara/video)
      mode = "MEDIA";
      sendToOne = async (userId) => {
        const opts = {};
        if (extraText) opts.caption = extraText;
        await bot.copyMessage(userId, chatId, reply.message_id, opts);
      };
    } else {
      // HANYA handle broadcast teks jika tidak ada handler lama
      // Jika pengguna kirim "/bcs teks" tanpa reply, handler lama mungkin sudah ada.
      // Untuk menghindari duplikasi, kita tetap handle di sini juga.
      const teks = extraText;
      if (!teks) {
        return bot.sendMessage(
          chatId,
          [
            "❌ Format salah.",
            "",
            "Cara pakai:",
            "• /bcs isi pesan",
            "   atau",
            "• Reply ke foto/video/dokumen lalu ketik /bcs [caption opsional]"
          ].join("\n"),
          { reply_to_message_id: msg.message_id }
        );
      }
      mode = "TEXT";
      sendToOne = async (userId) => {
        await bot.sendMessage(userId, teks);
      };
    }

    await bot.sendMessage(
      chatId,
      `⏳ Mulai broadcast ke ${users.length} user (mode: ${mode}). Mohon tunggu...`,
      { reply_to_message_id: msg.message_id }
    );

    let sukses = 0;
    let gagal  = 0;

    for (const uid of users) {
      try {
        await sendToOne(uid);
        sukses++;
      } catch (e) {
        gagal++;
      }
      // kecilin speed biar nggak spam
      await new Promise(r => setTimeout(r, 150));
    }

    await bot.sendMessage(
      chatId,
      [
        "✅ Broadcast selesai.",
        `• Berhasil: ${sukses} user`,
        `• Gagal: ${gagal} user`
      ].join("\n")
    );
  });
const sizeCommands = ["1gb","2gb","3gb","4gb","5gb","6gb","7gb","8gb","9gb","10gb","unlimited","unli"];
  for (const sc of sizeCommands) {
    bot.onText(new RegExp(`^\\/${sc}\\s*(.*)$`, "i"), async (msg, match) => {
      const from = msg.from; if (from.id !== config.OWNER_ID) return bot.sendMessage(msg.chat.id, "Fitur ini khusus owner.");
      const text = (match[1] || "").trim();
      if (!text) return bot.sendMessage(msg.chat.id, `*Contoh:* /${sc} username[,123456789]`, { parse_mode: "Markdown" });

      let username, targetId;
      if (text.includes(",")) { const parts = text.split(",").map(s => s.trim()); username = parts[0].toLowerCase(); targetId = parseInt(parts[1].replace(/[^0-9]/g, ""), 10); }
      else { username = text.toLowerCase(); targetId = msg.chat.id; }

      const map = {"1gb":{ram:"1000",disk:"1000",cpu:"40"},"2gb":{ram:"2000",disk:"1000",cpu:"60"},"3gb":{ram:"3000",disk:"2000",cpu:"80"},"4gb":{ram:"4000",disk:"2000",cpu:"100"},"5gb":{ram:"5000",disk:"3000",cpu:"120"},"6gb":{ram:"6000",disk:"3000",cpu:"140"},"7gb":{ram:"7000",disk:"4000",cpu:"160"},"8gb":{ram:"8000",disk:"4000",cpu:"180"},"9gb":{ram:"9000",disk:"5000",cpu:"200"},"10gb":{ram:"10000",disk:"5000",cpu:"220"},"unlimited":{ram:"0",disk:"0",cpu:"0"},"unli":{ram:"0",disk:"0",cpu:"0"}};
      const res = map[sc.toLowerCase()] || map["unlimited"];
      const email = `${username}@gmail.com`; const name = capital(username)+" Server"; const password = username + "001";
      try {
        const user = await ptero.createUser({ email, username, first_name: name, last_name: "Server", password });
        const server = await ptero.createServer({ name, description: tanggal(Date.now()), userId: user.id, ram: parseInt(res.ram), disk: parseInt(res.disk), cpu: parseInt(res.cpu) });
        const teks = ["*Berhasil membuat panel ✅*","",`📡 Server ID: ${server.id}`,`👤 Username: \`${user.username}\``,`🔐 Password: \`${password}\``,`🗓️ Tanggal Aktivasi: ${tanggal(Date.now())}`,"","*Spesifikasi server panel*",
          `- RAM: ${res.ram==="0"?"Unlimited":(parseInt(res.ram)/1000)+"GB"}`,`- Disk: ${res.disk==="0"?"Unlimited":(parseInt(res.disk)/1000)+"GB"}`,`- CPU: ${res.cpu==="0"?"Unlimited":res.cpu+"%"}`,`- Panel: ${config.PTERO_DOMAIN}`].join("\n");
        const kb = { inline_keyboard: [[{ text: "🔑 Login Panel", url: config.PTERO_DOMAIN }]] };
        try { await bot.sendMessage(targetId, teks, { parse_mode: "Markdown", reply_markup: kb }); if (targetId !== msg.chat.id) await bot.sendMessage(msg.chat.id, `Berhasil, data dikirim ke ID ${targetId}.`); }
        catch { await bot.sendMessage(msg.chat.id, "Target belum start bot atau ID salah. Data dikirim ke sini.", { reply_markup: kb }); await bot.sendMessage(msg.chat.id, teks, { parse_mode: "Markdown", reply_markup: kb }); }
      } catch (err) { await bot.sendMessage(msg.chat.id, "Terjadi kesalahan: " + (err.message || "")); }
    });
  }

bot.on("callback_query", async (query) => {
  const data = query.data;
  const msg = query.message;
  const chatId = msg.chat.id;
  const from = query.from;

  const db = loadDB();
  touchUser(db, from.id);

  try {
    if (data === "MENU") {
      await sendStartMenu(bot, chatId, from);

    } else if (data === "BUYRESELLER") {
      await askResellerId(bot, chatId, from);

    } else if (data === "LISTPRODUK") {
      await showProductList(bot, chatId);

    } else if (data && data.startsWith("BUYPROD_IDX:")) {
      const idx = parseInt(data.split(":")[1], 10);
      await startBuyProduct(bot, chatId, from, idx);

        // === QC color selector ===
    } else if (data && data.startsWith("QC_COLOR:")) {
      const colorKey = data.split(":")[1];
      const pendingText = qcPending.get(from.id);

      if (!pendingText) {
        await bot.answerCallbackQuery(query.id, {
          text: "Teks QC tidak ditemukan, kirim /qc lagi.",
          show_alert: true
        });
        return;
      }

      qcPending.delete(from.id); // habis dipakai, hapus

      await bot.answerCallbackQuery(query.id, {
        text: `Membuat QC warna ${colorKey}...`,
        show_alert: false
      });

      await generateQcSticker(bot, chatId, from, colorKey, pendingText, msg.message_id);

    } else if (data === "QC_CANCEL") {
      qcPending.delete(from.id);
      await bot.answerCallbackQuery(query.id, {
        text: "Dibatalkan.",
        show_alert: false
      });

    } else if (data === "ADDPRODUK_HELP") {
      if (from.id !== config.OWNER_ID) {
        return bot.sendMessage(chatId, "Menu ini khusus owner.", {
          reply_markup: backKeyboard()
        });
      }
      await addProdukHelp(bot, chatId);

    } else if (data === "DEVELOPERS") {
      await showDevelopers(bot, chatId);

    } else if (data === "BELIPANEL") {
      await askUsername(bot, chatId);

    } else if (data === "CHOOSE_PANEL_SERVER") {
      await askUsernameFor(bot, chatId, "panel");

    } else if (data === "CHOOSE_ADP") {
      await askUsernameFor(bot, chatId, "admin");

    } else if (data.startsWith("CHOOSE_RAM:")) {
      const username = data.split(":")[1];
      await sendRamOptions(bot, chatId, username);

    } else if (data.startsWith("BUYADP:")) {
      const username = data.split(":")[1];
      await startAdminPanel(bot, chatId, from, username);

    } else if (data === "CANCEL") {
      // Batalkan pembelian dari tombol
      const t = dbTransaksi.get(from.id);

      if (!t) {
        await bot.answerCallbackQuery(query.id, {
          text: "Tidak ada transaksi aktif.",
          show_alert: true
        });
      } else {
        try {
          clearTimeout(t.expTimeout);
        } catch {}

        try {
          await bot.deleteMessage(t.chat, t.msg.message_id);
        } catch {}

        dbTransaksi.delete(from.id);

        await bot.answerCallbackQuery(query.id, {
          text: "Transaksi dibatalkan.",
          show_alert: false
        });

        await bot.sendMessage(chatId, "Transaksi dibatalkan.", {
          reply_markup: backKeyboard()
        });
      }

    // ====== Deposit (Owner) ======
    } else if (data === "DEPOSIT_OWNER") {
      await askDepositAmount(bot, chatId, from);

    // ====== Hapus Produk (Owner) ======
    } else if (data === "DELPROD_MENU") {
      if (from.id !== config.OWNER_ID) {
        return bot.sendMessage(chatId, "Menu ini khusus owner.", {
          reply_markup: backKeyboard()
        });
      }
      await showDeleteProducts(bot, chatId);

    } else if (data && data.startsWith("DELPROD_IDX:")) {
      if (from.id !== config.OWNER_ID) {
        return bot.sendMessage(chatId, "Menu ini khusus owner.", {
          reply_markup: backKeyboard()
        });
      }
      const idx = parseInt(data.split(":")[1], 10);
      await deleteProductByIndex(bot, chatId, idx);

    } else if (data.startsWith("BUYRAM:")) {
      const payload = data.substring(7);
      const [planKey, username] = payload.split("|");
      await startPanelRam(bot, chatId, from, username, planKey);

        // === /installtema: user memilih tema ===
    } else if (data && data.startsWith("INSTALLTEMA:")) {
      const idxStr = data.split(":")[1];
      const themeIndex = parseInt(idxStr, 10);

      const session = installTemaSessions.get(from.id);
      if (!session || session.step !== "choose_theme") {
        await bot.answerCallbackQuery(query.id, {
          text: "Sesi /installtema tidak ditemukan. Jalankan /installtema lagi.",
          show_alert: true
        });
        return;
      }

      await bot.answerCallbackQuery(query.id, {
        text: "Memulai proses instalasi tema...",
        show_alert: false
      });

      try {
        const themes = await fetchInstallTemaThemeList();
        const theme = themes.find(t => t.index === themeIndex);
        if (!theme) {
          await bot.sendMessage(chatId, "❌ Tema tidak ditemukan di installer. Coba lagi /installtema.");
          installTemaSessions.delete(from.id);
          return;
        }

        // Jalankan instalasi via SSH
        await installThemeViaSSH(bot, chatId, from, session.data, theme);
      } finally {
        // Selesai atau error sama-sama menghapus session untuk keamanan
        installTemaSessions.delete(from.id);
      }

    } else if (data.startsWith("CEK:")) {
      const [_p, orderId, amountStr] = data.split(":");
      const amount = Number(amountStr);

      try {
        const trx = await pakasir.getTransactionDetail({ amount, orderId });
        const text = [
          "<b>Detail Transaksi</b>",
          `Order ID: <code>${trx.order_id}</code>`,
          `Nominal: Rp ${formatRupiah(trx.amount)}`,
          `Status: <b>${trx.status}</b>`,
          `Metode: ${trx.payment_method || "-"}`,
          trx.completed_at ? `Sukses pada: <code>${trx.completed_at}</code>` : ""
        ]
          .filter(Boolean)
          .join("\n");

        await bot.sendMessage(chatId, text, {
          parse_mode: "HTML",
          reply_markup: backKeyboard()
        });
      } catch (e) {
        await sendSafeError(bot, chatId, "Gagal cek transaksi", e);
      }
    }
  } catch (err) {
    await sendSafeError(bot, chatId, "Terjadi kesalahan saat memproses tombol.", err);
  }
});


async function showProductList(bot, chatId) {
  const list = buildProductList();
  if (!list.length) return bot.sendMessage(chatId, "Belum ada produk yang tersedia.");
  let teks = "🛒 *List Produk*\n\n";
  const rows = [];
  list.forEach((p, i) => {
    const h = Number(p.harga || 0);
    teks += `• ${p.nama} — *Rp${formatRupiah(h)}*\n`;
    rows.push([{ text: `Beli: ${p.nama} (Rp${formatRupiah(h)})`, callback_data: `BUYPROD_IDX:${i}` }]);
  });
  rows.push([{ text: "⬅️ Kembali", callback_data: "MENU" }]);
  await bot.sendMessage(chatId, teks, { parse_mode: "Markdown", reply_markup: { inline_keyboard: rows } });
}

async function startBuyProduct(bot, chatId, from, prodIndex) {
  const db = loadDB();
  const list = db.settings.products || [];
  const item = list[prodIndex];
  if (!item) return bot.sendMessage(chatId, "Produk tidak ditemukan.");
  if (dbTransaksi.get(from.id)) return bot.sendMessage(chatId, "Masih ada transaksi berjalan. Ketik /batalbeli untuk membatalkan.");

  const base = Number(item.harga || 0);
  const amount = base + rand(config.UNIQUE_MIN, config.UNIQUE_MAX);
  const orderId = `PRD-${from.id}-${Date.now()}`;
  const captionLines = [
    "*INFORMASI PEMBAYARAN*",
    "",
    `- Order ID: *${orderId}*`,
    `- Total: *Rp${formatRupiah(amount)}*`,
    `- Barang: *${item.nama}*`,
    `- Expired QRIS: *5 menit*`
  ];

  return createQrisAndSend(bot, chatId, from, {
    orderId,
    amount,
    captionLines,
    onCompleted: onProductPaid,
    variant: "product",
    context: { product: item, prodIndex },
    loadingText: "tunggu sebentar sedang membuat qris"
  });
}

async function onProductPaid(bot, userId) {
  const t = dbTransaksi.get(userId);
  if (!t) return;
  t.status = false; try { clearTimeout(t.expTimeout); } catch {}
  const { chat, context } = t;
  const { product } = context;

  await bot.sendMessage(chat, [
    "✅ *PEMBAYARAN BERHASIL*",
    "",
    `- Barang: *${product.nama}*`,
    `- Waktu: ${tanggal(Date.now())}`
  ].join("\n"), { parse_mode: "Markdown" });

  try {
    if (product.type === "file" && product.path && fs.existsSync(product.path)) {
      await bot.sendDocument(chat, product.path, { caption: `Produk: ${product.nama}` });
    } else if (product.type === "link" && product.link) {
      const kb = { inline_keyboard: [[{ text: "🔗 Buka Link", url: product.link }], [{ text: "⬅️ Kembali", callback_data: "MENU" }]] };
      await bot.sendMessage(chat, `Produk: *${product.nama}*\n\n${product.deskripsi || "-" }\n\nLink: ${product.link}`, { parse_mode: "Markdown", reply_markup: kb });
    } else {
      await bot.sendMessage(chat, "Produk tidak memiliki file/link yang valid.", { reply_markup: { inline_keyboard: [[{ text: "⬅️ Kembali", callback_data: "MENU" }]] } });
    }
  } catch (err) {
    await bot.sendMessage(chat, "Pembayaran berhasil, tetapi pengiriman produk gagal: " + (err.message || ""));
  } finally {
    dbTransaksi.delete(userId);
  }
}

bot.onText(/^\/cekidch$/, async (msg) => {
  const uid = msg.from?.id;
  const cid = msg.chat?.id;
  const teks = [
    `🆔 ID Telegram kamu: <code>${uid}</code>`,
    (cid && cid !== uid) ? `🆔 ID Chat ini: <code>${cid}</code>` : ""
  ].filter(Boolean).join("\n");
  await bot.sendMessage(msg.chat.id, teks, { parse_mode: "HTML" });
});

bot.onText(/^\/addproduk\s*(.*)$/i, async (msg, match) => {
  const chatId = msg.chat.id; const from = msg.from;
  if (from.id !== config.OWNER_ID) return bot.sendMessage(chatId, "Perintah ini khusus owner.");
  const textArg = (match[1] || "").trim();
  const quoted = msg.reply_to_message;

  const db = loadDB(); db.settings.products = db.settings.products || [];

  if (quoted && quoted.document) {
    if (!textArg.includes("|")) return bot.sendMessage(chatId, "Format: /addproduk Nama Produk|20000 (reply ke file .zip)");
    const [namaRaw, hargaRaw] = textArg.split("|").map(s => (s||"").trim());
    const nama = namaRaw || "";
    const harga = Number(hargaRaw || "");
    if (!nama || !harga || isNaN(harga)) return bot.sendMessage(chatId, "Nama/harga tidak valid.");

    const doc = quoted.document;
    const mimeType = (doc.mime_type || "").toLowerCase();
    const origName = (doc.file_name || "").toLowerCase();
    if (!(mimeType.includes("zip") || origName.endsWith(".zip"))) return bot.sendMessage(chatId, "File harus berformat .zip");

    let fileName = (nama.replace(/\s+/g, "-").replace(/[^a-zA-Z0-9._-]/g, "").toLowerCase() || "produk");
    let destPath = path.join(DATA_DIR, fileName + ".zip"); let idx = 1;
    while (fs.existsSync(destPath)) { destPath = path.join(DATA_DIR, fileName + "-" + idx + ".zip"); idx++; }

    try {
      const url = await bot.getFileLink(doc.file_id);
      const res = await axios.get(url, { responseType: "arraybuffer" });
      fs.writeFileSync(destPath, Buffer.from(res.data));

      db.settings.products.push({
        type: "file",
        nama,
        harga: String(harga),
        path: destPath,
        deskripsi: "",
        added_at: new Date().toISOString()
      });
      saveDB(db);
      await bot.sendMessage(chatId, `✅ Berhasil menambahkan produk file\n• Nama: ${nama}\n• Harga: Rp${formatRupiah(harga)}\n• Path: ${destPath}`);
    } catch (err) {
      await bot.sendMessage(chatId, "Gagal menyimpan file: " + (err.message || ""));
    }
    return;
  }

  if (!textArg || !textArg.includes("|")) {
    return addProdukHelp(bot, chatId);
  }
  const parts = textArg.split("|").map(s => (s||"").trim());
  const nama = parts[0] || "";
  const harga = Number(parts[1] || "");
  const link = parts[2] || "";
  const desk = parts.slice(3).join("|") || "";
  if (!nama || !harga || isNaN(harga)) return bot.sendMessage(chatId, "Nama/harga tidak valid.");
  if (!/^https?:\/\//i.test(link) && !/^t\.me\//i.test(link)) return bot.sendMessage(chatId, "Link harus diawali http(s) atau t.me/");

  db.settings.products.push({
    type: "link",
    nama,
    harga: String(harga),
    link: /^t\.me\//i.test(link) ? `https://${link}` : link,
    deskripsi: desk,
    added_at: new Date().toISOString()
  });
  saveDB(db);
  await bot.sendMessage(chatId, `✅ Berhasil menambahkan produk link\n• Nama: ${nama}\n• Harga: Rp${formatRupiah(harga)}\n• Link: ${link || "-"}`);
});

bot.onText(/^\/listproduk$/i, async (msg) => {
  await showProductList(bot, msg.chat.id);
});

bot.onText(/^\/buyreseller\s*(.*)$/i, async (msg, match) => {
  const chatId = msg.chat.id; const from = msg.from;
  const maybeId = (match[1] || "").trim();
  if (!maybeId) return askResellerId(bot, chatId, from);
  const idNum = parseInt(maybeId.replace(/[^0-9]/g, ""), 10);
  if (!idNum) return bot.sendMessage(chatId, "ID Telegram tidak valid. Ketik /cekidch untuk melihat ID kamu.");
  await startBuyReseller(bot, chatId, from, idNum);
});


async function addProdukHelp(bot, chatId) {
  const txt = [
    "<b>Tambah Produk — Owner</b>",
    "",
    "Opsi A) <b>File .zip</b>",
    "1) Kirim file .zip ke bot",
    "2) <i>Reply</i> file-nya dengan perintah:",
    "<code>/addproduk Nama Produk|20000</code>",
    "",
    "Opsi B) <b>Link Grup / Link Akses</b>",
    "Kirim perintah:",
    "<code>/addproduk Nama Produk|20000|https://link-atau-t.me/grup</code>",
    "",
    "Setelah tersimpan, produk otomatis muncul di <b>Listproduk</b>."
  ].join("\n");
  await bot.sendMessage(chatId, txt, { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅️ Kembali", callback_data: "MENU" }]] } });
}

async function askResellerId(bot, chatId, from) {
  resellerPrompt.set(from.id, true);
  await bot.sendMessage(
    chatId,
    "Masukkan <b>ID Telegram</b> kamu.\nKalau belum tahu, ketik <code>/cekidch</code> dulu.",
    { parse_mode: "HTML", reply_markup: { force_reply: true } }
  );
}

async function startBuyReseller(bot, chatId, from, targetTelegramId) {
  if (dbTransaksi.get(from.id)) return bot.sendMessage(chatId, "Masih ada transaksi berjalan. Ketik /batalbeli untuk membatalkan.");
  const base = Number(config.HARGA_RESELLER || 50000);
  const amount = base + rand(config.UNIQUE_MIN, config.UNIQUE_MAX);
  const orderId = `RES-${from.id}-${Date.now()}`;
  const captionLines = [
    "*INFORMASI PEMBAYARAN*",
    "",
    `- Order ID: *${orderId}*`,
    `- Total: *Rp${formatRupiah(amount)}*`,
    `- Barang: *Reseller*`,
    `- ID Telegram: *${targetTelegramId}*`,
    `- Expired QRIS: *5 menit*`
  ];

  return createQrisAndSend(bot, chatId, from, {
    orderId,
    amount,
    captionLines,
    onCompleted: onResellerPaid,
    variant: "reseller",
    context: { resellerId: String(targetTelegramId) },
    loadingText: "tunggu sebentar sedang membuat qris"
  });
}

async function onResellerPaid(bot, userId) {
  const t = dbTransaksi.get(userId);
  if (!t) return;

  // hentikan timer & tandai selesai
  t.status = false;
  try { clearTimeout(t.expTimeout); } catch {}

  const { chat, amount, idDeposit, context } = t;
  const resellerId = context?.resellerId || "-";
  const db = loadDB();

  // simpan ke database.json
  db.reseller_orders = db.reseller_orders || [];
  db.reseller_orders.push({
    order_id: t.orderId || idDeposit || `RES-${userId}`,
    buyer_user_id: userId,
    target_telegram_id: resellerId,
    amount: Number(amount || 0),
    created_at: new Date().toISOString()
  });
  saveDB(db);

  // kabari owner
  const owner = config.OWNER_ID;
  const linesOwner = [
    "🔔 <b>Pembelian Reseller (PAID)</b>",
    `• Buyer: <a href="tg://user?id=${userId}">${userId}</a>`,
    `• ID Telegram target: <code>${resellerId}</code>`,
    `• Total: <b>Rp${formatRupiah(Number(amount || 0))}</b>`,
    `• Waktu: ${new Date().toLocaleString("id-ID")}`
  ].join("\n");
  try {
    await bot.sendMessage(owner, linesOwner, { parse_mode: "HTML" });
  } catch {}

  // balas ke user (pakai Markdown saja biar aman)
  const linesUser = [
    "✅ *PEMBAYARAN BERHASIL*",
    "",
    `- Produk: *Reseller*`,
    `- ID Telegram: *${resellerId}*`,
    `- Total: *Rp${formatRupiah(Number(amount || 0))}*`,
    "",
    "_Data kamu sudah dikirim ke owner untuk diproses._",
    "untuk create panel hubungi owner: @Yopandelreyz",
    "*Jika ID Telegram kamu belum masuk ke database, mohon ditunggu — owner mungkin sedang sekolah atau tidur.*"
  ].join("\n");

  await bot.sendMessage(chat, linesUser, {
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: [[{ text: "⬅️ Kembali", callback_data: "MENU" }]] }
  });

  dbTransaksi.delete(userId);
}

// Handler state input untuk /installtema (IP -> username -> password -> port)
bot.on("message", async (msg) => {
  const from = msg.from;
  const chatId = msg.chat.id;
  const text = (msg.text || "").trim();

  // Kalau tidak ada session /installtema untuk user ini, lewati
  const session = installTemaSessions.get(from.id);
  if (!session) return;

  // Jangan proses pesan yang merupakan command (biar /installtema dll aman)
  if (text.startsWith("/")) return;

  const step = session.step;
  const data = session.data || (session.data = {});

  try {
    if (step === "ask_ip") {
      if (!text || text.includes(" ")) {
        await bot.sendMessage(chatId, "IP VPS tidak valid. Kirim lagi tanpa spasi, contoh: <code>1.2.3.4</code>", {
          parse_mode: "HTML"
        });
        return;
      }
      data.host = text;
      session.step = "ask_user";
      await bot.sendMessage(chatId, "Masukkan <b>username VPS</b> (default: <code>root</code>). Jika kosong kirim saja <code>root</code>.", {
        parse_mode: "HTML"
      });

    } else if (step === "ask_user") {
      data.username = text || "root";
      session.step = "ask_pass";
      await bot.sendMessage(
        chatId,
        "Masukkan <b>password VPS</b> kamu.\n\n<i>Password tidak akan ditampilkan ulang oleh bot.</i>",
        { parse_mode: "HTML" }
      );

    } else if (step === "ask_pass") {
      if (!text) {
        await bot.sendMessage(chatId, "Password tidak boleh kosong. Kirim lagi password VPS kamu.");
        return;
      }
      data.password = text;
      session.step = "ask_port";
      await bot.sendMessage(
        chatId,
        "Masukkan <b>port SSH</b> (default: <code>22</code>). Jika ragu, kirim saja <code>22</code>.",
        { parse_mode: "HTML" }
      );

    } else if (step === "ask_port") {
      let port = 22;
      if (text) {
        const p = parseInt(text, 10);
        if (!isNaN(p) && p > 0 && p <= 65535) port = p;
      }
      data.port = port;

      session.step = "choose_theme";

      await bot.sendMessage(
        chatId,
        [
          "✅ Data VPS tersimpan:",
          "",
          `• IP: <code>${escapeHtml(data.host)}</code>`,
          `• User: <code>${escapeHtml(data.username)}</code>`,
          `• Port: <code>${port}</code>`,
          "",
          "Sekarang pilih tema yang ingin diinstall:"
        ].join("\n"),
        { parse_mode: "HTML" }
      );

      await sendInstallTemaKeyboard(bot, chatId);
    }

  } catch (e) {
    console.error("[/installtema] state handler error:", e?.message);
    installTemaSessions.delete(from.id);
    await bot.sendMessage(chatId, "❌ Terjadi kesalahan di sesi /installtema. Silakan jalankan /installtema lagi.");
  }
});

// ====== DEVELOPERS ======
async function showDevelopers(bot, chatId) {
  const kb = {
    inline_keyboard: [
      [{ text: "Telegram Developer", url: "https://t.me/Yopandelreyz" }],
      [{ text: "WhatsApp Developer", url: "https://wa.me/6281239977516" }],
      [{ text: "⬅️ Kembali", callback_data: "MENU" }]
    ]
  };
  await bot.sendMessage(chatId, "Kontak Developer:", { reply_markup: kb });
}

// Handler ForceReply khusus "Buy Reseller" (minta ID Telegram)
bot.on("message", async (msg) => {
  const from = msg.from; const chatId = msg.chat.id;
  if (!resellerPrompt.get(from.id)) return; // tidak sedang menunggu input reseller

  const text = (msg.text || "").trim();
  const idNum = parseInt(text.replace(/[^0-9]/g, ""), 10);
  if (!idNum) {
    return bot.sendMessage(chatId, "ID Telegram tidak valid. Ketik /cekidch untuk melihat ID kamu, lalu balas lagi pesan sebelumnya.");
  }

  resellerPrompt.delete(from.id);
  await startBuyReseller(bot, chatId, from, idNum);
});


  // ===== New Commands: Owner-only utilities =====

  // /enchard or /enc -> obfuscate JS file from document or reply
  bot.onText(/^\/(enchard|enc)(?:\s+(.+))?$/i, async (msg, match) => {
    try {
      const chatId = msg.chat.id; const from = msg.from;
      if (from.id !== config.OWNER_ID) return bot.sendMessage(chatId, "❌ Khusus Owner!");

      const target = msg.reply_to_message || msg;
      const doc = target.document;
      if (!doc || !doc.file_name || !/\.js$/i.test(doc.file_name)) {
        return bot.sendMessage(chatId, "Kirim/reply dokumen *.js* lalu gunakan /enchard", { parse_mode: "Markdown" });
      }
      await bot.sendMessage(chatId, "🔐 Memproses encrypt...");
      const buf = await downloadTelegramFile(bot, doc.file_id);
      const inPath = path.join(TMP_DIR, "@hardenc-" + doc.file_name);
      fs.writeFileSync(inPath, buf);
      const JsConfuser = require("js-confuser");
      const code = fs.readFileSync(inPath, "utf-8");
      const obfuscated = await JsConfuser.obfuscate(code, {
        target: "node",
        preset: "high",
        compact: true,
        minify: true,
        flatten: true,
        identifierGenerator: function () {
          const originalString = "/*悪魔の死/*^/*($break)*/" + "/*悪魔の死/*^/*($break)*/";
          function hapusKarakterTidakDiinginkan(input) {
            return input.replace(/[^a-zA-Z]/g, '');
          }
          function stringAcak(panjang) {
            let hasil = '';
            const karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            const panjangKarakter = karakter.length;
            for (let i = 0; i < panjang; i++) {
              hasil += karakter.charAt(Math.floor(Math.random() * panjangKarakter));
            }
            return hasil;
          }
          return hapusKarakterTidakDiinginkan(originalString) + stringAcak(2);
        },
        renameVariables: true,
        renameGlobals: true,
        stringEncoding: 0.01,
        stringSplitting: 0.1,
        stringConcealing: true,
        stringCompression: true,
        duplicateLiteralsRemoval: true,
        shuffle: { hash: false, booleans: false },
        stack: false,
        controlFlowFlattening: false,
        opaquePredicates: false,
        deadCode: false,
        dispatcher: false,
        rgf: false,
        calculator: false,
        hexadecimalNumbers: false,
        movedDeclarations: true,
        objectExtraction: true,
        globalConcealing: true
      });
      const outPath = path.join(TMP_DIR, "@hardenc-" + doc.file_name);
      fs.writeFileSync(outPath, obfuscated);
      await bot.sendDocument(chatId, outPath, { caption: "Sukses! Type:\nString" }, { reply_to_message_id: msg.message_id });
      try { fs.unlinkSync(outPath); } catch {}
      try { fs.unlinkSync(inPath); } catch {}
    } catch (err) {
      console.error("enchard error:", err);
      bot.sendMessage(msg.chat.id, "Error: " + (err && err.message ? err.message : err));
    }
  });

  // /done | /don | /proses | /ps -> promosi transaksi (Owner only)
  bot.onText(/^\/(done|don|proses|ps)\s+(.+)$/i, async (msg, match) => {
    const chatId = msg.chat.id; const from = msg.from;
    if (from.id !== config.OWNER_ID) return bot.sendMessage(chatId, "❌ Khusus Owner!");
    const command = (match[1] || "").toLowerCase();
    const textArg = (match[2] || "").trim();
    const status = /^(done|don)$/.test(command) ? "Transaksi Done ✅" : "Dana Telah Diterima ✅";
    const teks = [
      `<b>${status}</b>`,
      "",
      `📦 Pembelian: <b>${escapeHtml(textArg)}</b>`,
      `🗓️ Tanggal: <b>${escapeHtml(tanggal(Date.now()))}</b>`,
      "",
      `📢 Cek Testimoni Pembeli:`,
      `${config.linkChannel || "-"}`,
      "",
      `📣 Gabung Grup Share & Promosi:`,
      `${config.linkGrup || "-"}`
    ].join("\n");
    const kb = {
      inline_keyboard: [[
        { text: "Channel Testimoni", url: config.linkChannel || "https://t.me" },
        { text: "Grup Marketplace", url: config.linkGrup || "https://t.me" }
      ]]
    };
    await bot.sendMessage(chatId, teks, { parse_mode: "HTML", reply_markup: kb });
  });

// /done /proses tanpa keterangan -> kasih contoh
bot.onText(/^\/(done|don|proses|ps)$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const from = msg.from;
  if (from.id !== config.OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Khusus Owner!");
  }

  const cmd = (match[1] || "").toLowerCase();
  const judul = /^(done|don)$/.test(cmd) ? "Transaksi Done" : "Dana Diterima";

  const teks = [
    `📌 *${judul}*`,
    "",
    "Format:",
    "/done keterangan transaksi",
    "/proses keterangan transaksi",
    "",
    "Contoh:",
    "/done Panel 4GB 30 hari untuk @username",
    "/proses Transfer 100k dari 089xxxx"
  ].join("\n");

  await bot.sendMessage(chatId, teks, { parse_mode: "Markdown" });
});


  // /payment | /pay -> daftar payment + QRIS (Owner only)
  bot.onText(/^\/(payment|pay)$/i, async (msg) => {
    const chatId = msg.chat.id; const from = msg.from;
    if (from.id !== config.OWNER_ID) return bot.sendMessage(chatId, "❌ Khusus Owner!");
    const caption = `<b>Daftar Payment</b>\nKlik tombol untuk menyalin nomor e-wallet.`;
    const kb = {
      inline_keyboard: [
        [{ text: "Copy Dana", callback_data: "COPY_DANA" }],
        [{ text: "Copy OVO", callback_data: "COPY_OVO" }],
        [{ text: "Copy Gopay", callback_data: "COPY_GOPAY" }],
        [{ text: "⬅️ Kembali", callback_data: "MENU" }]
      ]
    };
    try {
      if (config.qris) {
        await bot.sendPhoto(chatId, config.qris, { caption, parse_mode: "HTML", reply_markup: kb });
      } else {
        await bot.sendMessage(chatId, caption, { parse_mode: "HTML", reply_markup: kb });
      }
    } catch (e) {
      console.error("payment photo send err:", e);
      await bot.sendMessage(chatId, caption, { parse_mode: "HTML", reply_markup: kb });
    }
  });

  // Upload to Catbox helper
  async function uploadToCatbox(buffer, filename) {
    const FormData = require("form-data");
    const form = new FormData();
    form.append("reqtype", "fileupload");
    form.append("fileToUpload", buffer, filename || "file.bin");
    const res = await axios.post("https://catbox.moe/user/api.php", form, { headers: form.getHeaders() });
    return String(res.data).trim();
  }

  // /tourl -> universal media to URL via Catbox
  bot.onText(/^\/(tourl)$/i, async (msg) => {
    const chatId = msg.chat.id;
    const q = msg.reply_to_message;
    if (!q) return bot.sendMessage(chatId, `Media tidak ditemukan!\nBalas (reply) media lalu ketik /tourl`);
    const media = q.photo ? q.photo[q.photo.length-1] : (q.document || q.video || q.audio);
    if (!media) return bot.sendMessage(chatId, `Media tidak ditemukan!\nBalas (reply) media lalu ketik /tourl`);
    const fileId = media.file_id;
    let filename = "file.bin";
    if (q.document && q.document.file_name) filename = q.document.file_name;
    else if (q.photo) filename = "photo.jpg";
    else if (q.video) filename = "video.mp4";
    else if (q.audio) filename = "audio.mp3";
    const buf = await downloadTelegramFile(bot, fileId);
    const url = await uploadToCatbox(buf, filename);

    // Store in memory to support copy via callback
    if (!global.__copyStore) global.__copyStore = new Map();
    const id = Math.random().toString(36).slice(2, 10);
    global.__copyStore.set(id, url);
    setTimeout(() => global.__copyStore.delete(id), 10*60*1000);

    const kb = { inline_keyboard: [[
      { text: "Open URL", url },
      { text: "Copy URL", callback_data: "COPY_URL:" + id }
    ]] };
    await bot.sendMessage(chatId, `✅ Media berhasil diupload!\n\nURL: ${url}`, { reply_markup: kb });
  });

  // /tourl2 -> foto only via Catbox (tanpa dependency tambahan)
  bot.onText(/^\/(tourl2)$/i, async (msg) => {
    const chatId = msg.chat.id;
    const q = msg.reply_to_message;
    if (!q || !q.photo) return bot.sendMessage(chatId, `Media tidak ditemukan!\nBalas (reply) *foto* lalu ketik /tourl2`, { parse_mode: "Markdown" });
    const media = q.photo[q.photo.length-1];
    const buf = await downloadTelegramFile(bot, media.file_id);
    const url = await uploadToCatbox(buf, "image.jpg");
    if (!global.__copyStore) global.__copyStore = new Map();
    const id = Math.random().toString(36).slice(2, 10);
    global.__copyStore.set(id, url);
    setTimeout(() => global.__copyStore.delete(id), 10*60*1000);
    const kb = { inline_keyboard: [[
      { text: "Open URL", url },
      { text: "Copy URL", callback_data: "COPY_URL:" + id }
    ]] };
    await bot.sendMessage(chatId, `✅ Foto berhasil diupload!\n\nURL: ${url}`, { reply_markup: kb });
  });

// /backupsc | /bck | /backup -> zip entire project (exclude heavy dirs)
bot.onText(/^\/(backupsc|bck|backup)$/i, async (msg) => {
  const chatId = msg.chat.id;
  const from = msg.from;
  if (from.id !== config.OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Khusus Owner!");
  }

  await bot.sendMessage(chatId, "Processing Backup Script . .");

  const archiver = require("archiver");
  const name = "Script-Gateway-V3";
  const outPath = path.join(TMP_DIR, name + ".zip");
  try { fs.unlinkSync(outPath); } catch {}

  const output = fs.createWriteStream(outPath);
  const archive = archiver("zip", { zlib: { level: 9 } });
  archive.pipe(output);

  const exclude = [
    "node_modules/**",
    "tmp/**",
    "session/**",
    "server/session/**",
    ".git/**",
    ".cache/**",
    ".npm/**"
  ];
  archive.glob("**/*", { cwd: __dirname, dot: true, ignore: exclude });

  try {
    await new Promise((resolve, reject) => {
      output.on("close", resolve);
      archive.on("error", reject);
      archive.finalize();
    });

    try {
      await bot.sendDocument(from.id, outPath, {}, {});
      if (chatId !== from.id) {
        await bot.sendMessage(chatId, "Script bot berhasil dikirim ke private chat.");
      }
    } catch (e) {
      console.error("send zip err:", e);
      await bot.sendMessage(chatId, "Terjadi kesalahan saat melakukan backup.");
    }
  } finally {
    try { fs.unlinkSync(outPath); } catch {}
  }
});

  // ===================== /struk =======================
  bot.onText(/^\/struk(?:\s+([\s\S]+))?$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const text = (match[1] || "").trim();

    // format: /struk nama toko|nama pembeli|nomor pembeli|nominal|produk
    if (!text) {
      return bot.sendMessage(
        chatId,
        [
          "📄 Format salah!",
          "Gunakan:",
          "/struk nama toko|nama pembeli|nomor pembeli|nominal|produk",
          "",
          "Contoh:",
          "/struk Yopan Hosting|Budi|6281234567890|15000|Pembelian Panel 1GB"
        ].join("\n")
      );
    }

    const [namaToko, namaPembeli, nomorPembeli, nominalRaw, produk] = text.split("|").map(s => (s || "").trim());

    if (!namaToko || !namaPembeli || !nomorPembeli || !nominalRaw || !produk) {
      return bot.sendMessage(
        chatId,
        "❌ Data tidak lengkap!\nPastikan format: /struk nama toko|nama pembeli|nomor pembeli|nominal|produk"
      );
    }

    // bersihin nominal jadi angka (kalau bisa)
    const angkaNominal = parseInt(nominalRaw.replace(/[^\d]/g, ""), 10);
    const nominalTampil = isNaN(angkaNominal)
      ? nominalRaw
      : "Rp" + angkaNominal.toLocaleString("id-ID");

    const now = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
    const noTrx = Math.floor(Math.random() * 1e10);

    let teks = "";
    teks += "🧾 <b>STRUK PEMBAYARAN</b>\n\n";
    teks += `🏪 Toko     : <b>${namaToko}</b>\n`;
    teks += `👤 Pembeli  : <b>${namaPembeli}</b>\n`;
    teks += `📞 Kontak   : <code>${nomorPembeli}</code>\n`;
    teks += `📦 Produk   : ${produk}\n`;
    teks += `💵 Nominal  : <b>${nominalTampil}</b>\n\n`;
    teks += `📅 Tanggal  : ${now}\n`;
    teks += `🔢 No. Trx  : <code>${noTrx}</code>\n\n`;
    teks += `Terima kasih telah berbelanja 🙏`;

    await bot.sendMessage(chatId, teks, { parse_mode: "HTML" });
  });

  // ===================== /report =======================
  bot.onText(/^\/report(?:\s+([\s\S]+))?$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const from = msg.from;
    const teks = (match[1] || "").trim();

    if (!teks) {
      return bot.sendMessage(
        chatId,
        "🚨 *Contoh:*\n" +
          "/report fitur /menu error kak, ga muncul balasan\n\n" +
          "📝 Jelaskan dengan detail ya, biar owner gampang cek!",
        { parse_mode: "Markdown" }
      );
    }

    if (!config.OWNER_ID) {
      return bot.sendMessage(
        chatId,
        "❌ ID owner belum diatur di config.OWNER_ID (angka ID Telegram)."
      );
    }

    const userTag = from.username ? "@" + from.username : (from.first_name || "User");
    const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

    const laporan = [
      "╭─❏ LAPORAN FITUR DARI USER",
      "│",
      `│👤 Pengirim: ${userTag}`,
      `│🆔 ID     : ${from.id}`,
      `│🕒 Waktu  : ${waktu}`,
      "│",
      "│🧩 Isi laporan:",
      ...teks.split("\n").map((line) => "│ " + line),
      "╰──────────────❏",
    ].join("\n");

    try {
      await bot.sendMessage(config.OWNER_ID, laporan);
      await bot.sendMessage(
        chatId,
        "✅ Laporan kamu sudah dikirim ke owner.\nTerima kasih sudah bantu improve bot ini 🙌"
      );
    } catch (e) {
      console.error("[/report] error:", e);
      await bot.sendMessage(
        chatId,
        "❌ Gagal mengirim laporan ke owner. Owner mungkin belum pernah chat bot."
      );
    }
  });

  // ======================= /req ========================
  bot.onText(/^\/req(?:\s+([\s\S]+))?$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const from = msg.from;
    const teks = (match[1] || "").trim();

    if (!teks) {
      return bot.sendMessage(
        chatId,
        "🚨 *Contoh:*\n" +
          "/req tolong tambahkan fitur menu dark mode\n\n" +
          "📝 Jelaskan dengan detail ya, biar owner gampang cek!",
        { parse_mode: "Markdown" }
      );
    }

    if (!config.OWNER_ID) {
      return bot.sendMessage(
        chatId,
        "❌ ID owner belum diatur di config.OWNER_ID (angka ID Telegram)."
      );
    }

    const userTag = from.username ? "@" + from.username : (from.first_name || "User");
    const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

    const laporan = [
      "╭─❏ REQUEST FITUR DARI USER",
      "│",
      `│👤 Pengirim: ${userTag}`,
      `│🆔 ID     : ${from.id}`,
      `│🕒 Waktu  : ${waktu}`,
      "│",
      "│🧩 Isi request:",
      ...teks.split("\n").map((line) => "│ " + line),
      "╰──────────────❏",
    ].join("\n");

    try {
      await bot.sendMessage(config.OWNER_ID, laporan);
      await bot.sendMessage(
        chatId,
        "✅ Request kamu sudah dikirim ke owner.\nTerima kasih ya 🙌"
      );
    } catch (e) {
      console.error("[/req] error:", e);
      await bot.sendMessage(
        chatId,
        "❌ Gagal mengirim request ke owner. Owner mungkin belum pernah chat bot."
      );
    }
  });

  // ===================== /spotify /ssp =======================
  bot.onText(/^\/(spotify|ssp)(?:\s+([\s\S]+))?$/i, async(msg, match) => {
    const chatId = msg.chat.id;
    const query = (match[2] || "").trim();

    if (!query) return bot.sendMessage(chatId, "📌 Contoh: /spotify judul lagu");

    try {
      let res = await fetch(`https://api-ghostx.biz.id/api/search/spotifysearch?q=${encodeURIComponent(query)}`);
      let data = await res.json();

      if (!data.status || !data.result.length) return bot.sendMessage(chatId, "❌ Lagu tidak ditemukan!");

      let list = data.result.slice(0, 5);

      let text = "🎵 *Hasil Pencarian Spotify:*\n\n";
      list.forEach((lagu, i) => {
        text += `${i+1}. *${lagu.trackName}* — ${lagu.artistName}\n`;
        text += `/spdown ${lagu.externalUrl}\n\n`;
      });

      bot.sendMessage(chatId, text, { parse_mode: "Markdown" });

    } catch(e) {
      bot.sendMessage(chatId, "❌ Error mengambil data Spotify!");
    }
  });

// ===================== /spdown =======================
bot.onText(/^\/spdown(?:\s+(\S+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = (match[1] || "").trim();

  if (!url) {
    return bot.sendMessage(
      chatId,
      "🚩 Gunakan:\n/spdown url_spotify\n\nContoh:\n/spdown https://open.spotify.com/track/xxxx"
    );
  }

  await bot.sendMessage(chatId, "⏳ Sedang memproses link Spotify kamu...");

  try {
    // 1. HIT API SPOTIFY SIPUTZX
    const apiUrl = `https://api.siputzx.my.id/api/d/spotifyv2?url=${encodeURIComponent(url)}`;
    const res = await fetch(apiUrl);

    if (!res.ok) {
      throw new Error(`Gagal menghubungi API (status: ${res.status})`);
    }

    const data = await res.json();
    console.log("Spotify API response:", data);

    if (!data || data.status === false) {
      throw new Error(data?.message || "API balas status=false");
    }

    const info = data.data || data;
    if (!info) throw new Error("Field data di response kosong / tidak ada");

    const audioUrl = info.mp3DownloadLink;
    if (!audioUrl) throw new Error("mp3DownloadLink tidak ditemukan di data.data");

    const title  = info.songTitle || info.title || "Unknown Title";
    const artist = info.artist || "Unknown Artist";
    const rawDuration = info.duration || info.duration_ms || info.durationMs;

    let durationSeconds;
    let durationText = "Unknown";

    if (typeof rawDuration === "number") {
      durationSeconds = rawDuration > 1000 ? Math.round(rawDuration / 1000) : rawDuration;
      const m = Math.floor(durationSeconds / 60);
      const s = durationSeconds % 60;
      durationText = `${m}:${s.toString().padStart(2, "0")}`;
    } else if (typeof rawDuration === "string") {
      durationText = rawDuration;
    }

    // 2. DOWNLOAD AUDIO DI SERVER BOT (BUKAN TELEGRAM)
    const audioRes = await fetch(audioUrl);
    if (!audioRes.ok) {
      throw new Error(`Gagal download audio (status: ${audioRes.status})`);
    }
    const arrayBuffer = await audioRes.arrayBuffer();
    const audioBuffer = Buffer.from(arrayBuffer);

    // 3. CAPTION KEREN (TANPA parse_mode BIAR AMAN)
    const caption = `
╭───────────────────────────╮
│ 🎵 SPOTIFY DOWNLOADER
├───────────────────────────┤
│ • Judul  : ${title}
│ • Artis  : ${artist}
│ • Durasi : ${durationText}
│ • URL    : ${url}
╰───────────────────────────╯
    `.trim();

    // 4. KIRIM FILE AUDIO KE TELEGRAM
    await bot.sendAudio(chatId, audioBuffer, {
      caption: caption,
      title: title,
      performer: artist,
      ...(typeof durationSeconds === "number" ? { duration: durationSeconds } : {})
    });

  } catch (e) {
    console.error("/spdown ERROR:", e);
    bot.sendMessage(
      chatId,
      "❌ Gagal memproses Spotify!\nDetail (untuk owner bot): " + (e.message || e.toString())
    );
  }
});

  
  // /iqc | /ipchat | /fakeiphonechat -> Fake iPhone Chat Image
  bot.onText(/^\/(iqc|ipchat|fakeiphonechat)\s+(.+)$/i, async (msg, match) => {
    const chatId = msg.chat.id; const from = msg.from;
    if (from.id !== config.OWNER_ID) return bot.sendMessage(chatId, "❌ Khusus Owner!");
    const textAll = match[2] || "";
    const parts = textAll.split("|");
    if (parts.length < 2) return bot.sendMessage(chatId, "❌ Masukkan teks!\n\nContoh: /iqc hallo|23:00");
    const message = parts[0].trim();
    const chatTime = parts[1].trim();
    if (message.length > 80) return bot.sendMessage(chatId, "🍂 Teks terlalu panjang! Maksimal 80 karakter.");
    try {
      const url = `https://alipai-api.vercel.app/imagecreator/iqc?apikey=alipaikey&time=${encodeURIComponent(chatTime)}&text=${encodeURIComponent(message)}`;
      const res = await axios.get(url, { responseType: "arraybuffer" });
      const buf = Buffer.from(res.data);
      await bot.sendPhoto(chatId, buf, { caption: `✨ *Fake Chat iPhone*\n\n💬 Pesan: ${message}\n⏰ Waktu Chat: ${chatTime}`, parse_mode: "Markdown" }, { reply_to_message_id: msg.message_id });
    } catch (err) {
      console.error("iqc error:", err);
      await bot.sendMessage(chatId, "❌ Gagal membuat Fake Chat iPhone, coba lagi nanti.");
    }
  });
  
  // /iqc tanpa argumen -> kasih contoh pemakaian
bot.onText(/^\/(iqc|ipchat|fakeiphonechat)$/i, async (msg) => {
  const chatId = msg.chat.id;
  const from = msg.from;
  if (from.id !== config.OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Khusus Owner!");
  }
  const teks = [
  "📸 *Fake iPhone Chat*",
  "",
  "Format:",
  "/iqc teks pesan|jam:menit",
  "",
  "Contoh:",
  "/iqc Halo sayang|23:00"
].join("\n");

await bot.sendMessage(chatId, teks, { parse_mode: "Markdown" });
});


  // ===================== /alphaai (toggle AI chat) =======================
  bot.onText(/^\/alphaai\b/i, async (msg) => {
    const chatId = msg.chat.id;
    const from = msg.from;
    const db = loadDB();
    touchUser(db, from.id);
    const on = isAlphaAIOn(db, chatId);
    const kb = {
      inline_keyboard: [
        [
          { text: on ? "✅ ON" : "ON", callback_data: "ALPHAAI:ON" },
          { text: !on ? "✅ OFF" : "OFF", callback_data: "ALPHAAI:OFF" }
        ],
        [{ text: "ℹ️ Cara pakai", callback_data: "ALPHAAI:HOW" }]
      ]
    };
    const txt = on
      ? "Alpha AI saat ini: *AKTIF*\n\nSetiap pesan teks baru (bukan perintah /) akan dibalas oleh AI."
      : "Alpha AI saat ini: *NONAKTIF*\n\nTekan tombol *ON* untuk mengaktifkan balasan AI otomatis.";
    await bot.sendMessage(chatId, txt, { parse_mode: "Markdown", reply_markup: kb, reply_to_message_id: msg.message_id });
  });

  // Callback untuk tombol /alphaai
  bot.on("callback_query", async (query) => {
    try {
      const data = query.data || "";
      if (!data.startsWith("ALPHAAI:")) return;
      const chatId = query.message.chat.id;
      const from = query.from;
      const db = loadDB();
      touchUser(db, from.id);
      const action = data.split(":")[1];
      if (action === "HOW") {
        return bot.answerCallbackQuery(query.id, { text: "Aktifkan ON untuk auto-reply AI. Ketik pesan biasa (bukan /command).", show_alert: true });
      }
      if (action === "ON") {
        if (!hasOpenRouterKey()) {
          const who = (from.id === config.OWNER_ID) ? "Owner, set variabel OPENROUTER_API_KEY di config.js" : "Maaf, AI belum dikonfigurasi oleh owner.";
          await bot.answerCallbackQuery(query.id, { text: who, show_alert: true });
          return;
        }
        setAlphaAI(db, chatId, true);
      } else if (action === "OFF") {
        setAlphaAI(db, chatId, false);
      }
      // Update pesan
      const on = isAlphaAIOn(db, chatId);
      const kb = {
        inline_keyboard: [[
          { text: on ? "✅ ON" : "ON", callback_data: "ALPHAAI:ON" },
          { text: !on ? "✅ OFF" : "OFF", callback_data: "ALPHAAI:OFF" }
        ],[{ text: "ℹ️ Cara pakai", callback_data: "ALPHAAI:HOW" }]]
      };
      const txt = on
        ? "Alpha AI saat ini: *AKTIF*\n\nSetiap pesan teks baru (bukan perintah /) akan dibalas oleh AI."
        : "Alpha AI saat ini: *NONAKTIF*\n\nTekan tombol *ON* untuk mengaktifkan balasan AI otomatis.";
      await bot.editMessageText(txt, { chat_id: chatId, message_id: query.message.message_id, parse_mode: "Markdown", reply_markup: kb });
      await bot.answerCallbackQuery(query.id, { text: "Disimpan.", show_alert: false });
    } catch (e) {
      console.error("[ALPHAAI callback] error:", e);
      try { await bot.answerCallbackQuery(query.id, { text: "Terjadi kesalahan.", show_alert: true }); } catch {}
    }
  });

  // Auto-reply AI ketika ON
  bot.on("message", async (msg) => {
    try {
      const chatId = msg.chat.id;
      const from = msg.from || {};
      const text = (msg.text || "").trim();
      if (!text) return;                            // hanya teks
      if (text.startsWith("/")) return;             // abaikan command
      if (depositPrompt.get(from.id)) return;       // lagi input deposit
      if (resellerPrompt.get(from.id)) return;      // lagi input reseller

      const db = loadDB();
      if (!isAlphaAIOn(db, chatId)) return;

      if (!hasOpenRouterKey()) {
        // Hanya beritahu owner, agar tidak spam user lain
        if (from.id === config.OWNER_ID) {
          await bot.sendMessage(chatId, "OPENROUTER_API_KEY belum diatur di config.js — AI tidak bisa dijalankan.", { reply_to_message_id: msg.message_id });
        }
        return;
      }

      // siapkan konteks percakapan singkat
      const key = String(chatId);
      const hist = alphaSessions.get(key) || [];
      const messages = [...alphaSystemPrompt(), ...hist.slice(-8), { role: "user", content: text }];

      await bot.sendChatAction(chatId, "typing");
      const answer = await alphaAIChat(messages);
      const replyText = typeof answer === "string" ? answer : (answer?.content || String(answer));

      // simpan riwayat
      hist.push({ role: "user", content: text });
      hist.push({ role: "assistant", content: replyText });
      alphaSessions.set(key, hist.slice(-10));

      await bot.sendMessage(chatId, replyText, { reply_to_message_id: msg.message_id });
    } catch (err) {
      console.error("[AlphaAI message] error:", err);
    }
  });

bot.onText(/^\/qc(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const from = msg.from;
  const text = (match[1] || "").trim();

  if (!text) {
    return bot.sendMessage(
      chatId,
      `📌 Contoh: /qc Hai kak`,
      { reply_to_message_id: msg.message_id }
    );
  }

  if (text.length > 100) {
    return bot.sendMessage(
      chatId,
      "⚠️ Maksimal 100 karakter.",
      { reply_to_message_id: msg.message_id }
    );
  }

  // simpan teks user ke map (per user)
  qcPending.set(from.id, text);

  // build inline keyboard warna (pakai helper packButtons biar rapi)
  const items = QC_COLOR_BUTTONS.map(c => ({
    text: c.label,
    cb: "QC_COLOR:" + c.id
  }));
  const rows = packButtons(items, 14);
  rows.push([{ text: "❌ Batal", callback_data: "QC_CANCEL" }]);

  const caption = [
    "🎨 *Pilih Warna QC*",
    "",
    "Silakan pilih warna efek QC yang ingin kamu gunakan."
  ].join("\n");

  await bot.sendMessage(chatId, caption, {
    parse_mode: "Markdown",
    reply_to_message_id: msg.message_id,
    reply_markup: { inline_keyboard: rows }
  });
});

bot.onText(/^\/forceqc\s*(.*)$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const from = msg.from;
  const textAll = (match[1] || "").trim();

  if (!textAll) {
    return bot.sendMessage(
      chatId,
      [
        "*Masukan Input Query!*",
        "",
        "Contoh:",
        "/forceqc pink hallo",
        "",
        "*List Warna:*",
        "pink",
        "biru",
        "merah",
        "hijau",
        "kuning",
        "ungu",
        "birutua",
        "birumuda",
        "abu",
        "orange",
        "hitam",
        "putih",
        "teal",
        "merahmuda",
        "cokelat",
        "salmon",
        "magenta",
        "tan",
        "wheat",
        "deeppink",
        "api",
        "birulangit",
        "jingga",
        "birulangitcerah",
        "hotpink",
        "birumudalangit",
        "hijaulaut",
        "merahtua",
        "oranyemerah",
        "cyan",
        "ungutua",
        "hijaulumut",
        "hijaugelap",
        "birulaut",
        "oranyetua",
        "ungukehitaman",
        "fuchsia",
        "magentagelap",
        "abu-abutua",
        "peachpuff",
        "hijautua",
        "merahgelap",
        "goldenrod",
        "emas",
        "perak"
      ].join("\n"),
      { parse_mode: "Markdown" }
    );
  }

  let [color, ...rest] = textAll.split(" ");
  color = (color || "").toLowerCase();
  let message = rest.join(" ").trim();

  // kalau warna nggak dikenal, anggap semua sebagai teks dan pakai putih
  if (!QC_COLOR_MAP[color]) {
    message = textAll;
    color = "putih";
  }

  if (!message) {
    return bot.sendMessage(
      chatId,
      "Teks tidak boleh kosong.",
      { reply_to_message_id: msg.message_id }
    );
  }

  if (message.length > 100) {
    return bot.sendMessage(
      chatId,
      "⚠️ Maksimal 100 karakter.",
      { reply_to_message_id: msg.message_id }
    );
  }

  await generateQcSticker(bot, chatId, from, color, message, msg.message_id);
});

// ===================== /tiktok /tt /ttdl =======================
bot.onText(/^\/(tt|tiktok|ttdl)\s*(.*)$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const cmd = (match[1] || "tiktok").toLowerCase();
  const text = (match[2] || "").trim();

  if (!text) {
    return bot.sendMessage(
      chatId,
      `*Contoh :* /${cmd} https://www.tiktok.com/@user/video/123`,
      { parse_mode: "Markdown" }
    );
  }

  if (!/^https?:\/\//i.test(text)) {
    return bot.sendMessage(
      chatId,
      `*Contoh :* /${cmd} https://www.tiktok.com/@user/video/123`,
      { parse_mode: "Markdown" }
    );
  }

  await bot.sendMessage(chatId, "⏳ Sedang mengunduh dari TikTok...");

  try {
    const res = await tiktok(text);
    if (!res || !res.data) {
      return bot.sendMessage(chatId, "Error! result tidak ditemukan");
    }

    const data = res.data;

    // Slide / album
    if (Array.isArray(data.images) && data.images.length) {
      const media = data.images.map((url, idx) => ({
        type: "photo",
        media: url,
        caption: idx === 0 ? "Tiktok Slide Downloader ✅" : undefined,
      }));

      try {
        await bot.sendMediaGroup(chatId, media);
      } catch {
        // fallback kirim satu-satu kalau gagal media group
        for (const url of data.images) {
          await bot.sendPhoto(chatId, url, {
            caption: "Tiktok Slide Downloader ✅",
          });
        }
      }
    } else if (data.hdplay || data.play) {
      const videoUrl = data.hdplay || data.play;
      await bot.sendVideo(chatId, videoUrl, {
        caption: "Tiktok Downloader ✅",
      });
    } else if (res.result && res.result.data && res.result.data.play) {
      await bot.sendVideo(chatId, res.result.data.play, {
        caption: "Tiktok Downloader ✅",
      });
    }

    if (data.music) {
      await bot.sendAudio(chatId, data.music, {
        caption: "🎵 Audio TikTok",
        title: "TikTok Music",
      });
    }
  } catch (err) {
    console.error("/tiktok error:", err);
    await bot.sendMessage(
      chatId,
      "❌ Gagal download dari TikTok: " + (err.message || err)
    );
  }
});

// ===================== /sora2 =======================
bot.onText(/^\/sora2(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  let prompt = (match[1] || "").trim();

  if (!prompt) {
    return bot.sendMessage(
      chatId,
      "*Example:*\n" +
        "/sora2 cat walking in space\n\n" +
        "Tambahkan `9:16`, `16:9`, atau `1:1` di prompt untuk mengatur rasio.",
      { parse_mode: "Markdown" }
    );
  }

  let aspect = "16:9";

  if (/9:16|vertical/i.test(prompt)) {
    aspect = "9:16";
    prompt = prompt.replace(/9:16|vertical/gi, "").trim();
  } else if (/1:1|square/i.test(prompt)) {
    aspect = "1:1";
    prompt = prompt.replace(/1:1|square/gi, "").trim();
  } else if (/16:9|horizontal/i.test(prompt)) {
    aspect = "16:9";
    prompt = prompt.replace(/16:9|horizontal/gi, "").trim();
  }

  const loadingMsg = await bot.sendMessage(
    chatId,
    `*Generating Sora video...*\n"${prompt}" (${aspect})`,
    { parse_mode: "Markdown" }
  );

  try {
    // STEP 1: mulai generate
    const startRes = await axios.post(
      SORA_API_START,
      { prompt, aspectRatio: aspect },
      {
        headers: { "Content-Type": "application/json" },
        timeout: 30000,
      }
    );

    if (!startRes.data || !startRes.data.success || !startRes.data.videoId) {
      throw new Error(startRes.data?.message || "Failed to start generation");
    }

    const videoId = startRes.data.videoId;

    await bot.editMessageText(
      `*Queued!*\nVideo ID: \`${videoId}\`\nPolling status every 10s...`,
      {
        chat_id: chatId,
        message_id: loadingMsg.message_id,
        parse_mode: "Markdown",
      }
    );

    // STEP 2: polling status
    let videoUrl = null;
    for (let i = 0; i < 40; i++) {
      await sleep(10000);

      const statusRes = await axios.get(
        `${SORA_API_STATUS}?videoId=${encodeURIComponent(videoId)}`
      );
      const data = statusRes.data || {};

      if (data.status === "completed" && data.videoUrl) {
        videoUrl = data.videoUrl;
        break;
      }

      if (data.status === "failed") {
        throw new Error(
          "Video generation failed: " + (data.message || "Unknown reason")
        );
      }

      if (typeof data.progress === "number") {
        try {
          await bot.editMessageText(
            `*In progress...* ${data.progress}%`,
            {
              chat_id: chatId,
              message_id: loadingMsg.message_id,
              parse_mode: "Markdown",
            }
          );
        } catch {}
      }
    }

    if (!videoUrl) {
      throw new Error("Timeout: Video took too long");
    }

    const caption = [
      "Sora Video Generated!",
      "",
      `*Prompt:* ${prompt}`,
      `*Ratio:* ${aspect}`,
      `*ID:* \`${videoId}\``,
      "",
      "---",
      "*Credit:* Omegatech",
      `*Follow Channel:* ${OMEGATECH_CHANNEL}`,
    ].join("\n");

    await bot.sendChatAction(chatId, "upload_video");
    await bot.sendVideo(chatId, videoUrl, {
      caption,
      parse_mode: "Markdown",
    });

    try {
      await bot.editMessageText("Done!", {
        chat_id: chatId,
        message_id: loadingMsg.message_id,
      });
    } catch {}
  } catch (e) {
    console.error("/sora2 error:", e);
    try {
      await bot.editMessageText(
        `*Error:* ${e.message || e}`,
        {
          chat_id: chatId,
          message_id: loadingMsg.message_id,
          parse_mode: "Markdown",
        }
      );
    } catch {
      await bot.sendMessage(
        chatId,
        "❌ Gagal generate video: " + (e.message || e)
      );
    }
  }
});

// ===================== /addprotectpanel (Owner) =======================
bot.onText(/^\/addprotectpanel(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const from = msg.from;

  // hanya owner
  if (from.id !== config.OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Perintah ini khusus owner.");
  }

  const text = (msg.text || "").trim();
  const args = text.split(/\s+/); // [/addprotectpanel, IP, PASSWORD...]

  if (args.length < 3) {
    return bot.sendMessage(
      chatId,
      '⚠️ <b>Format Salah!</b>\n\nGunakan:\n<code>/addprotectpanel IP_VPS PASSWORD_VPS</code>\n\nContoh:\n<code>/addprotectpanel 103.10.10.10 p4ssw0rdKuat</code>',
      { parse_mode: "HTML", reply_to_message_id: msg.message_id }
    );
  }

  const host = args[1];
  const password = args.slice(2).join(" ");
  const username = "root";

  const statusMsg = await bot.sendMessage(
    chatId,
    `🔄 <b>Connecting to ${escapeHtml(host)}...</b>\n\nMohon tunggu sebentar, sedang menanam script proteksi...`,
    { parse_mode: "HTML" }
  );

  // script bash yang akan dieksekusi di VPS
  const scriptPayload = `
REMOTE_PATH="/var/www/pterodactyl/app/Http/Controllers/Api/Client/Servers/ServerController.php"
TIMESTAMP=$(date -u +"%Y-%m-%d-%H-%M-%S")
BACKUP_PATH="\${REMOTE_PATH}.bak_\${TIMESTAMP}"

echo "🚀 Memulai pemasangan proteksi di ${host}..."

# Cek file target
if [ -f "$REMOTE_PATH" ]; then
    mv "$REMOTE_PATH" "$BACKUP_PATH"
    echo "📦 Backup file lama dibuat: $BACKUP_PATH"
else
    echo "⚠️ File target tidak ditemukan! Pastikan ini server Pterodactyl."
fi

# Buat folder jika belum ada (preventif)
mkdir -p "$(dirname "$REMOTE_PATH")"
chmod 755 "$(dirname "$REMOTE_PATH")"

# Tulis File PHP Baru (Menggunakan 'EOF' agar variabel PHP $ tidak dieksekusi oleh Bash)
cat > "$REMOTE_PATH" << 'EOF'
<?php

namespace Pterodactyl\\Http\\Controllers\\Api\\Client\\Servers;

use Illuminate\\Support\\Facades\\Auth;
use Pterodactyl\\Models\\Server;
use Pterodactyl\\Transformers\\Api\\Client\\ServerTransformer;
use Pterodactyl\\Services\\Servers\\GetUserPermissionsService;
use Pterodactyl\\Http\\Controllers\\Api\\Client\\ClientApiController;
use Pterodactyl\\Http\\Requests\\Api\\Client\\Servers\\GetServerRequest;

class ServerController extends ClientApiController
{
    /**
     * ServerController constructor.
     */
    public function __construct(private GetUserPermissionsService $permissionsService)
    {
        parent::__construct();
    }

    /**
     * Transform an individual server into a response that can be consumed by a
     * client using the API.
     */
    public function index(GetServerRequest $request, Server $server): array
    {
        $authUser = Auth::user();
        if ($authUser->id !== 1 && (int) $server->owner_id !== (int) $authUser->id) {
            abort(403, '𝗔𝗸𝘀𝗲𝘀 𝗗𝗶 𝗧𝗼𝗹𝗮𝗸❌. 𝗛𝗮𝗻𝘆𝗮 𝗕𝗶𝘀𝗮 𝗠𝗲𝗹𝗶𝗵𝗮𝘁 𝗦𝗲𝗿𝘃𝗲𝗿 𝗠𝗶𝗹𝗶𝗸 𝗦𝗲𝗻𝗱𝗶𝗿𝗶.');
        }

        return $this->fractal->item($server)
            ->transformWith($this->getTransformer(ServerTransformer::class))
            ->addMeta([
                'is_server_owner' => $request->user()->id === $server->owner_id,
                'user_permissions' => $this->permissionsService->handle($server, $request->user()),
            ])
            ->toArray();
    }
}
EOF

chmod 644 "$REMOTE_PATH"
echo "✅ SUCCESS: Proteksi Server Controller berhasil dipasang!"
`;

  const conn = new Client();
  let outputLog = "";

  conn
    .on("ready", () => {
      // Jalankan bash dan kirim script lewat stdin
      conn.exec("bash -s", (err, stream) => {
        if (err) {
          conn.end();
          return bot
            .editMessageText(
              `❌ <b>Error Exec:</b> ${escapeHtml(err.message || String(err))}`,
              {
                chat_id: chatId,
                message_id: statusMsg.message_id,
                parse_mode: "HTML",
              }
            )
            .catch(() => {});
        }

        stream
          .on("close", (code, signal) => {
            conn.end();
            const safeLog = escapeHtml(outputLog || "(no output)");
            if (code === 0) {
              bot
                .editMessageText(
                  `<b>✅ BERHASIL DIPASANG!</b>\nHost: <code>${escapeHtml(
                    host
                  )}</code>\n\n<b>Log Output:</b>\n<pre>${safeLog}</pre>`,
                  {
                    chat_id: chatId,
                    message_id: statusMsg.message_id,
                    parse_mode: "HTML",
                  }
                )
                .catch(() => {});
            } else {
              bot
                .editMessageText(
                  `<b>⚠️ GAGAL / PERINGATAN (Code: ${code})</b>\nHost: <code>${escapeHtml(
                    host
                  )}</code>\n\n<b>Log Output:</b>\n<pre>${safeLog}</pre>`,
                  {
                    chat_id: chatId,
                    message_id: statusMsg.message_id,
                    parse_mode: "HTML",
                  }
                )
                .catch(() => {});
            }
          })
          .on("data", (data) => {
            outputLog += data.toString();
          })
          .stderr.on("data", (data) => {
            outputLog += "[STDERR] " + data.toString();
          });

        // kirim isi script ke bash
        stream.end(scriptPayload);
      });
    })
    .on("error", (err) => {
      bot
        .editMessageText(
          `❌ <b>Koneksi Gagal!</b>\nHost: <code>${escapeHtml(
            host
          )}</code>\nError: ${escapeHtml(
            err.message || String(err)
          )}\n\n<i>Pastikan IP dan Password benar.</i>`,
          {
            chat_id: chatId,
            message_id: statusMsg.message_id,
            parse_mode: "HTML",
          }
        )
        .catch(() => {});
    })
    .connect({
      host,
      port: 22,
      username,
      password,
      readyTimeout: 20000,
    });
});

// === /installtema ===
bot.onText(/^\/installtema$/i, async (msg) => {
  const from = msg.from;
  const chatId = msg.chat.id;

  installTemaSessions.set(from.id, {
    step: "ask_ip",
    data: {}
  });

  await bot.sendMessage(
    chatId,
    [
      "🧩 <b>Install Tema Pterodactyl via SSH</b>",
      "",
      "Bot akan meminta data VPS kamu bertahap:",
      "1. IP VPS",
      "2. Username (default: <code>root</code>)",
      "3. Password",
      "4. Port SSH (default: <code>22</code>)",
      "",
      "Kirim sekarang <b>IP VPS</b> kamu:",
    ].join("\n"),
    { parse_mode: "HTML" }
  );
});

// Optional: batalin sesi /installtema
bot.onText(/^\/cancelinstalltema$/i, async (msg) => {
  const from = msg.from;
  const chatId = msg.chat.id;

  if (installTemaSessions.has(from.id)) {
    installTemaSessions.delete(from.id);
    await bot.sendMessage(chatId, "❌ Sesi /installtema dibatalkan.");
  } else {
    await bot.sendMessage(chatId, "Tidak ada sesi /installtema yang aktif.");
  }
});

// ===================== /installpanel — install panel Pterodactyl via SSH =======================
bot.onText(/^\/installpanel(?:\s+([\s\S]+))?/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const from   = msg.from;

  // Hanya owner
  if (from.id !== config.OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Fitur ini khusus owner.");
  }

  const text = (match[1] || "").trim();
  if (!text) {
    return bot.sendMessage(
      chatId,
      [
        "Format salah!",
        "",
        "*Contoh penggunaan:*",
        "`/installpanel ipvps|pwvps|panel.com|node.com|ramserver`",
        "",
        "Contoh:",
        "`/installpanel 1.2.3.4|passwordvps|panel.example.com|node.example.com|100000`"
      ].join("\n"),
      { parse_mode: "Markdown" }
    );
  }

  const vii = text.split("|");
  if (vii.length < 5) {
    return bot.sendMessage(
      chatId,
      [
        "Format salah!",
        "",
        "*Contoh penggunaan:*",
        "`/installpanel ipvps|pwvps|panel.com|node.com|ramserver`"
      ].join("\n"),
      { parse_mode: "Markdown" }
    );
  }

  const host        = vii[0].trim();
  const vpsPass     = vii[1].trim();
  const domainpanel = vii[2].trim();
  const domainnode  = vii[3].trim();
  const ramserver   = vii[4].trim() || "100000";

  const connSettings = {
    host,
    port: 22,
    username: "root",
    password: vpsPass
  };

  // Akun panel default (dari template WA kamu)
  const usernamePanel = "admin";
  const passwordPanel = "admin001";

  // Script installer (sesuai template kamu)
  const commandPanel   = "bash <(curl -s https://pterodactyl-installer.se)";
  const createNodeCmd  = "bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)";

  const conn = new Client();

  function normalizeUrl(dom) {
    if (!dom) return "";
    if (/^https?:\/\//i.test(dom)) return dom;
    return "https://" + dom;
  }

  function sendUsageError(errText) {
    const base = [
      "❌ Terjadi kesalahan saat install panel.",
      "",
      errText ? String(errText) : "",
      "",
      "*Pastikan format:*",
      "`/installpanel ipvps|pwvps|panel.com|node.com|ramserver`"
    ].join("\n");
    return bot.sendMessage(chatId, base, { parse_mode: "Markdown" });
  }

  // Saat SSH ready
  conn.on("ready", async () => {
    await bot.sendMessage(
      chatId,
      [
        "🚀 *Memproses install server panel...*",
        "",
        `*IP Address:* \`${host}\``,
        `*Domain Panel:* \`${domainpanel}\``,
        `*Domain Node:* \`${domainnode}\``,
        `*RAM Server:* \`${ramserver}\` MB`,
        "",
        "_Mohon tunggu 10–20 menit hingga proses install selesai._"
      ].join("\n"),
      { parse_mode: "Markdown" }
    );

    instalPanel();
  });

  conn.on("error", (err) => {
    console.error("SSH Connection Error (/installpanel):", err);
    const msgErr = err && err.message ? err.message : String(err);
    bot.sendMessage(
      chatId,
      "❌ Gagal terhubung ke server:\n<code>" + escapeHtml(msgErr) + "</code>",
      { parse_mode: "HTML" }
    ).catch(() => {});
  });

  // === 1. Install Panel ===
  function instalPanel() {
    conn.exec(commandPanel, { pty: true }, (err, stream) => {
      if (err) {
        console.error("Panel installation error:", err);
        sendUsageError(err.message || String(err));
        return conn.end();
      }

      stream.on("close", (code, signal) => {
        console.log("Panel install closed with code", code, "signal", signal);
        if (code !== 0) {
          sendUsageError("Instalasi panel gagal. Cek log di VPS.");
          return conn.end();
        }
        bot.sendMessage(chatId, "✅ Instalasi panel selesai. Melanjutkan instalasi Wings...").catch(() => {});
        instalWings();
      }).on("data", (data) => {
        const dataStr = data.toString();
        console.log("Panel Install:", dataStr);

        if (dataStr.includes("Input 0-6")) {
          stream.write("0\n");
        } else if (dataStr.includes("(y/N)")) {
          stream.write("y\n");
        } else if (dataStr.includes("Database name (panel)")) {
          stream.write("\n");
        } else if (dataStr.includes("Database username (pterodactyl)")) {
          stream.write("admin\n");
        } else if (dataStr.includes("Password (press enter to use randomly generated password)")) {
          stream.write("admin\n");
        } else if (dataStr.includes("Select timezone [Europe/Stockholm]")) {
          stream.write("Asia/Jakarta\n");
        } else if (dataStr.includes("Provide the email address that will be used to configure Let")) {
          stream.write("admin@gmail.com\n");
        } else if (dataStr.includes("Email address for the initial admin account")) {
          stream.write("admin@gmail.com\n");
        } else if (dataStr.includes("Username for the initial admin account")) {
          stream.write(usernamePanel + "\n");
        } else if (dataStr.includes("First name for the initial admin account")) {
          stream.write("admin\n");
        } else if (dataStr.includes("Last name for the initial admin account")) {
          stream.write("admin\n");
        } else if (dataStr.includes("Password for the initial admin account")) {
          stream.write(passwordPanel + "\n");
        } else if (dataStr.includes("Set the FQDN of this panel")) {
          stream.write(domainpanel + "\n");
        } else if (dataStr.includes("Do you want to automatically configure UFW")) {
          stream.write("y\n");
        } else if (dataStr.includes("Do you want to automatically configure HTTPS using Let")) {
          stream.write("y\n");
        } else if (dataStr.includes("Select the appropriate number [1-2]")) {
          stream.write("1\n");
        } else if (dataStr.includes("I agree that this HTTPS request is performed")) {
          stream.write("y\n");
        } else if (dataStr.includes("Proceed anyways")) {
          stream.write("y\n");
        } else if (dataStr.includes("(yes/no)")) {
          stream.write("y\n");
        } else if (dataStr.includes("Initial configuration completed. Continue with installation?")) {
          stream.write("y\n");
        } else if (dataStr.includes("Still assume SSL?")) {
          stream.write("y\n");
        } else if (dataStr.includes("Please read the Terms of Service")) {
          stream.write("y\n");
        } else if (dataStr.includes("(A)gree/(C)ancel:")) {
          stream.write("A\n");
        }
      }).stderr.on("data", (data) => {
        console.error("Panel Install STDERR:", data.toString());
      });
    });
  }

  // === 2. Install Wings ===
  function instalWings() {
    conn.exec(commandPanel, { pty: true }, (err, stream) => {
      if (err) {
        console.error("Wings installation error:", err);
        sendUsageError(err.message || String(err));
        return conn.end();
      }

      stream.on("close", (code, signal) => {
        console.log("Wings install closed with code", code, "signal", signal);
        if (code !== 0) {
          sendUsageError("Instalasi Wings gagal. Cek log di VPS.");
          return conn.end();
        }
        bot.sendMessage(chatId, "✅ Instalasi Wings selesai. Membuat node...").catch(() => {});
        InstallNodes();
      }).on("data", (data) => {
        const dataStr = data.toString();
        console.log("Wings Install:", dataStr);

        if (dataStr.includes("Input 0-6")) {
          stream.write("1\n");
        } else if (dataStr.includes("(y/N)")) {
          stream.write("y\n");
        } else if (dataStr.includes("Enter the panel address (blank for any address)")) {
          stream.write(domainpanel + "\n");
        } else if (dataStr.includes("Database host username")) {
          stream.write("admin\n");
        } else if (dataStr.includes("Database host password")) {
          stream.write("admin\n");
        } else if (dataStr.includes("Set the FQDN to use for Let")) {
          stream.write(domainnode + "\n");
        } else if (dataStr.includes("Enter email address for Let")) {
          stream.write("admin@gmail.com\n");
        }
      }).stderr.on("data", (data) => {
        console.error("Wings Install STDERR:", data.toString());
      });
    });
  }

  // === 3. Buat Node ===
  function InstallNodes() {
    conn.exec(createNodeCmd, { pty: true }, (err, stream) => {
      if (err) {
        console.error("Node creation error:", err);
        sendUsageError(err.message || String(err));
        return conn.end();
      }

      stream.on("close", async (code, signal) => {
        console.log("Create node closed with code", code, "signal", signal);

        const panelUrl = normalizeUrl(domainpanel);

        let teks = [
          "*Install Panel Telah Berhasil ✅*",
          "",
          "*Berikut Detail Akun Panel Kamu 📦*",
          "",
          `👤 Username : \`${usernamePanel}\``,
          `🔐 Password : \`${passwordPanel}\``,
          `🌐 ${panelUrl}`,
          "",
          "Silahkan setting allocation & ambil token node di node yang sudah dibuat oleh bot.",
          "",
          "*Cara menjalankan wings :*",
          "`.startwings ipvps|pwvps|tokennode`"
        ].join("\n");

        // Pakai mekanisme copy yang sudah ada (COPY_URL + __copyStore)
        if (!global.__copyStore) global.__copyStore = new Map();
        const idUser = Math.random().toString(36).slice(2, 10);
        const idPass = Math.random().toString(36).slice(2, 10);
        global.__copyStore.set(idUser, usernamePanel);
        global.__copyStore.set(idPass, passwordPanel);
        setTimeout(() => {
          if (!global.__copyStore) return;
          global.__copyStore.delete(idUser);
          global.__copyStore.delete(idPass);
        }, 10 * 60 * 1000);

        const kb = {
          inline_keyboard: [
            [
              { text: "Copy Username", callback_data: "COPY_URL:" + idUser },
              { text: "Copy Password", callback_data: "COPY_URL:" + idPass }
            ],
            [
              { text: "Login Panel", url: panelUrl }
            ]
          ]
        };

        await bot.sendMessage(chatId, teks, {
          parse_mode: "Markdown",
          reply_markup: kb
        }).catch(() => {});

        conn.end();
      }).on("data", (data) => {
        const s = data.toString();
        console.log("Create Node:", s);

        if (s.includes("Masukkan nama lokasi:")) {
          stream.write("Singapore\n");
        } else if (s.includes("Masukkan deskripsi lokasi:")) {
          stream.write("Node By Bot\n");
        } else if (s.includes("Masukkan domain:")) {
          stream.write(domainnode + "\n");
        } else if (s.includes("Masukkan nama node:")) {
          stream.write("AlphaNode\n");
        } else if (s.includes("Masukkan RAM (dalam MB):")) {
          stream.write(ramserver + "\n");
        } else if (s.includes("Masukkan jumlah maksimum disk space (dalam MB):")) {
          stream.write(ramserver + "\n");
        } else if (s.includes("Masukkan Locid:")) {
          stream.write("1\n");
        }
      }).stderr.on("data", (data) => {
        console.error("Create Node STDERR:", data.toString());
      });
    });
  }

  conn.connect(connSettings);
});

// ===================== /startwings — jalankan Wings node Pterodactyl =======================
bot.onText(/^\/(startwings|configurewings)(?:\s+([\s\S]+))?/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const from   = msg.from;

  // Hanya owner yang boleh
  if (from.id !== config.OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Fitur ini khusus owner.");
  }

  const text = (match[2] || "").trim();

  if (!text) {
    return bot.sendMessage(
      chatId,
      [
        "Format salah!",
        "",
        "*Contoh penggunaan:*",
        "`/startwings ipvps|pwvps|token_wings`",
        "",
        "Contoh:",
        "`/startwings 1.2.3.4|passwordvps|bash <token_wings_kamu>`"
      ].join("\n"),
      { parse_mode: "Markdown" }
    );
  }

  let t = text.split("|");
  if (t.length < 3) {
    return bot.sendMessage(
      chatId,
      [
        "Format salah!",
        "",
        "*Contoh penggunaan:*",
        "`/startwings ipvps|pwvps|token_wings`"
      ].join("\n"),
      { parse_mode: "Markdown" }
    );
  }

  let ipvps  = t[0].trim();
  let passwd = t[1].trim();
  let token  = t[2].trim();

  const connSettings = {
    host: ipvps,
    port: 22,
    username: "root",
    password: passwd,
  };

  // Di WA, command dibuat: `${token} && systemctl start wings`
  // Kita pakai pola yang sama di sini:
  const command = `${token} && systemctl start wings`;

  const ress = new Client();

  ress.on("ready", () => {
    console.log("SSH ready for /startwings ->", ipvps);

    ress.exec(command, { pty: true }, (err, stream) => {
      if (err) {
        console.error("Exec error /startwings:", err);
        bot.sendMessage(chatId, "❌ Gagal menjalankan perintah di VPS.");
        ress.end();
        return;
      }

      stream.on("close", async (code, signal) => {
        console.log("Wings command closed. Code:", code, "Signal:", signal);

        if (code === 0) {
          await bot.sendMessage(
            chatId,
            "✅ Berhasil menjalankan *wings* node panel Pterodactyl.",
            { parse_mode: "Markdown" }
          );
        } else {
          await bot.sendMessage(
            chatId,
            "⚠️ Perintah selesai tapi kode keluar bukan 0.\nCek log di VPS untuk detail lebih lanjut.",
          );
        }

        ress.end();
      }).on("data", (data) => {
        console.log("STDOUT /startwings:", data.toString());
      }).stderr.on("data", (data) => {
        const s = data.toString();
        console.log("STDERR /startwings:", s);

        // Mirip versi WA: coba jawab y + start wings kalau diminta konfirmasi
        try {
          stream.write("y\n");
          stream.write("systemctl start wings\n");
        } catch (e) {
          console.error("Error saat tulis ke stream /startwings:", e);
        }

        bot.sendMessage(
          chatId,
          "⚠️ Terjadi error saat eksekusi di VPS:\n<code>" + s + "</code>",
          { parse_mode: "HTML" }
        ).catch(() => {});
      });
    });
  }).on("error", (err) => {
    console.log("Connection Error /startwings:", err.message);
    bot.sendMessage(
      chatId,
      "❌ Gagal terhubung ke VPS: IP atau password salah.\n\n<code>" + err.message + "</code>",
      { parse_mode: "HTML" }
    ).catch(() => {});
  }).connect(connSettings);
});

// ===================== /subdo — pilih domain Cloudflare =======================
bot.onText(/^\/(subdo|subdomain)(?:\s+([\s\S]+))?/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const from   = msg.from;

  // Hanya owner
  if (from.id !== config.OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Fitur ini khusus owner.");
  }

  const text = (match[2] || "").trim();
  if (!text.includes("|")) {
    return bot.sendMessage(
      chatId,
      [
        "*Contoh penggunaan :*",
        "`/subdo hostname|ipvps`",
        "",
        "Contoh:",
        "`/subdo panelku|1.2.3.4`"
      ].join("\n"),
      { parse_mode: "Markdown" }
    );
  }

  const hostname = text.split("|")[0].trim().toLowerCase();
  const ip       = text.split("|")[1].trim();

  const subdomainConfig = config.SUBDOMAIN || config.subdomain || {};
  const domains = Object.keys(subdomainConfig);

  if (domains.length < 1) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada domain yang tersedia di config.SUBDOMAIN.");
  }

  // Buat inline keyboard daftar domain
  const rows = [];
  for (let i = 0; i < domains.length; i++) {
    const d = domains[i];
    rows.push([
      {
        text: `🌐 ${d}`,
        callback_data: `SUBDOMAIN_SELECT:${i}:${hostname}:${ip}`
      }
    ]);
  }

  const textMsg = [
    "Pilih Domain Server Yang Tersedia",
    "",
    `Total Domain: *${domains.length}*`
  ].join("\n");

  await bot.sendMessage(chatId, textMsg, {
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: rows
    }
  });
});

function startBot() {
  // Bot sudah dibuat di atas & handler sudah didaftarkan di file ini.
  console.log("Bot aktif: Panel + Admin Panel + Script + Broadcast + Audio + Slash menu — READY.");
  return bot;
}

// Export kalau mau dipanggil dari index.js
module.exports = { startBot, bot };