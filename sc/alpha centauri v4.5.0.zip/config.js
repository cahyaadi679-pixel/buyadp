module.exports = {

  // Telegram
  BOT_TOKEN: "8358754732:AAG6dLMFDO3Tos9rQLxh-HQhKae3KE54o3c",
  OWNER_ID: 8218627647,

  // Pakasir
  PAKASIR_PROJECT: "newproject",
  PAKASIR_API_KEY: "AsyIISrYJ67r9M8ZAAE33n5XvWaI9Fa9",
  IS_SANDBOX: false,

  // Pricing dasar
  HARGA_PANEL: 1000,
  HARGA_ADP: 13000,
  HARGA_RESELLER: 9000,
  UNIQUE_MIN: 110,
  UNIQUE_MAX: 250,

  // (Opsional) Harga Buyscript jika ingin mengaktifkan menu Buyscript cepat
  HARGA_BUYSCRIPT: 15000,

  //bisa di ganti apikeynya
  OPENROUTER_API_KEY: "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",

  // Pterodactyl
  PTERO_EGG: "15",
  PTERO_NEST_ID: "5",
  PTERO_LOC: "1",
  PTERO_DOMAIN: "https://alpha.yop4nhosting.my.id",
  PTERO_API_KEY: "ptla_lr5D0WEBXObW4mYLMUoXHusNkQqNgTo5wuYFbnTJF38",
  PTERO_CLIENT_KEY: "ptlc_AV8NDWJGcY15gPm6zUdtmF6qyHtcazC5aKfzHT2s2rL",

  linkGrup: "https://chat.whatsapp.com/CEJ1IPbfLVtDR5XPzCKG8r?mode=wwt",
  linkChannel: "https://whatsapp.com/channel/0029VbBvm6l17EmxNvDZtN2e",
  idChannel: "120363421119826661@newsletter",
  dana: "081239977516",
  ovo: "Tidak tersedia",
  gopay: "081239977516",
  qris: "https://files.catbox.moe/0kkyfm.jpg",

  //######## Setting Api Subdomain ########//
  SUBDOMAIN: {
    "skypedia.qzz.io": {
      zone: "59c189ec8c067f57269c8e057f832c74",
      apitoken: "mZd-PC7t7PmAgjJQfFvukRStcoWDqjDvvLHAJzHF"
    },
    "pteroweb.my.id": {
      zone: "714e0f2e54a90875426f8a6819f782d0",
      apitoken: "vOn3NN5HJPut8laSwCjzY-gBO0cxeEdgSLH9WBEH"
    },
    "panelwebsite.biz.id": {
      zone: "2d6aab40136299392d66eed44a7b1122",
      apitoken: "CcavVSmQ6ZcGSrTnOos-oXnawq4yf86TUhmQW29S"
    },
    "privatserver.my.id": {
      zone: "699bb9eb65046a886399c91daacb1968",
      apitoken: "CcavVSmQ6ZcGSrTnOos-oXnawq4yf86TUhmQW29S"
    },
    "serverku.biz.id": {
      zone: "4e4feaba70b41ed78295d2dcc090dd3a",
      apitoken: "CcavVSmQ6ZcGSrTnOos-oXnawq4yf86TUhmQW29S"
    },
    "vipserver.web.id": {
      zone: "e305b750127749c9b80f41a9cf4a3a53",
      apitoken: "cpny6vwi620Tfq4vTF4KGjeJIXdUCax3dZArCqnT"
    },
    "mypanelstore.web.id": {
      zone: "c61c442d70392500611499c5af816532",
      apitoken: "uaw-48Yb5tPqhh5HdhNQSJ6dPA3cauPL_qKkC-Oa"
    }
  },

};
